﻿Public Class Form1
    Const Exl = "C:\Program Files (x86)\Microsoft Office\Office16\EXCEL.EXE "
    Dim dataCount As Integer
    Dim plcComBusyFlag As Boolean

    '★★★　タイマー関連プログラム　★★★　タイマーセット～タイムアップチェック、指定時間待ち   Timer1 を使用　　-----------------------------

    Dim tm As Integer                   'Timerの現在値管理用変数
    Dim dt As Integer 'delay_time

    'タイマー起動
    Private Sub timinit()
        Timer1.Interval = 10
        Timer1.Enabled = True
    End Sub

    'インターバル10msで、タイマー用データをディクリメント
    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        If tm > 0 Then tm = tm - 1
    End Sub

    '時間を指定してタイマをセット（timchkとセットで使用する）　　tdt：待ち時間　　
    Private Sub timset(ByVal tdt As Integer)
        tm = tdt
    End Sub

    'タイムアップをチェック（timsetとセットで使用する）
    Private Function timchk() As Integer
        Return tm
    End Function

    '時間を指定してタイムアップまで待つ　　　tdt：待ち時間
    Private Sub timwait(ByVal tdt As Integer)
        timset(tdt)
        While timchk() <> 0
            Windows.Forms.Application.DoEvents()
        End While
    End Sub


    '★★★　ビットセット、クリア、テスト　★★★　16bitのデータを対象としたビットコントロール ---------------------------------------------------
    ' 指定ビットをON
    Public Function bset(ByVal dt As Integer, ByVal b As Integer) As Integer
        If (b >= 0) And (b <= 15) Then
            Return dt Or (2 ^ b)
        Else
            Return dt
        End If
    End Function

    '指定ビットをOFF
    Public Function bclr(ByVal dt As Integer, ByVal b As Integer) As Integer
        If (b >= 0) And (b <= 15) Then
            Return dt And (Not (2 ^ b))
        Else
            Return dt
        End If
    End Function

    '指定ビットをON/OFFをテスト
    Public Function btst(ByVal dt As Integer, ByVal b As Integer) As Boolean
        If (b >= 0) And (b <= 15) Then
            If (dt And (2 ^ b)) <> 0 Then
                Return True
            End If
        End If
        Return False
    End Function


    '★★★　PLCリンク用シリアル通信ポートの設定　★★★　Serial.Port1を使用    //////////////////////////////////////////////////////////

    'PLCリンクポートの設定用コンボボックスアイテムのデフォルト設定
    Private Sub comboBoxInit1()
        port1_search()
        cmb_port1.SelectedIndex = cmb_port1.Items.Count - 1 'コンボボックス一番下のアイテム
        cmb_baudrate1.SelectedIndex = 2     '38400
        cmb_databits1.SelectedIndex = 1     '8
        cmb_stopbits1.SelectedIndex = 0     '1
        cmb_parity1.SelectedIndex = 1       'Odd
    End Sub

    'PLCリンクシリアルポート設定用にCOM番号をリストアップ
    Private Sub port1_search()
        cmb_port1.Items.Clear()
        For Each sp As String In My.Computer.Ports.SerialPortNames
            cmb_port1.Items.Add(sp)   'アイテムを追加
        Next
    End Sub

    '通信ポート設定　マウスクリックでコンボボックスにCOM番号を表示
    Private Sub cmb_port1_click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmb_port1.MouseClick
        port1_search()
    End Sub

    'PLCリンク用シリアルポートの設定
    Private Sub btn_comset1_Click(sender As Object, e As EventArgs) Handles btn_comset1.Click
        If SerialPort1.IsOpen Then
            MsgBox("ポートが開いているので設定変更できませんでした")
            Exit Sub
        End If
        Select Case cmb_baudrate1.SelectedItem
            Case "9600"
                SerialPort1.BaudRate = "9600"
            Case "19200"
                SerialPort1.BaudRate = "19200"
            Case "38400"
                SerialPort1.BaudRate = "38400"
            Case "57600"
                SerialPort1.BaudRate = "57600"
            Case "115200"
                SerialPort1.BaudRate = "115200"
        End Select

        Select Case cmb_databits1.SelectedItem
            Case "7"
                SerialPort1.DataBits = 7
            Case "8"
                SerialPort1.DataBits = 8
        End Select

        Select Case cmb_stopbits1.SelectedItem
            Case "1"
                SerialPort1.StopBits = IO.Ports.StopBits.One
            Case "2"
                SerialPort1.StopBits = IO.Ports.StopBits.Two
        End Select

        Select Case cmb_parity1.SelectedItem
            Case "None"
                SerialPort1.Parity = IO.Ports.Parity.None
            Case "Odd"
                SerialPort1.Parity = IO.Ports.Parity.Odd
            Case "Even"
                SerialPort1.Parity = IO.Ports.Parity.Even
        End Select

        SerialPort1.PortName = cmb_port1.SelectedItem
        SerialPort1.ReadTimeout = 1000
        SerialPort1.WriteTimeout = 1000
    End Sub

    'PLCリンク用シリアルポートシリアルポートのオンライン/オフライン切り替え
    Private Sub btn_online1_Click(sender As Object, e As EventArgs) Handles btn_online1.Click
        If SerialPort1.IsOpen Then
            Try
                sd_data(2) = 0
                timwait(5)
                SerialPort1.Close()
                btn_online1.BackColor = Color.LightGray
                btn_online1.Text = "オフライン"
                Timer2.Enabled = False
                Exit Sub
            Catch ex As Exception
                MsgBox("Port1 Close Error: " & ex.Message)
            End Try
        Else
            Try
                sd_data(2) = 1
                timwait(5)
                SerialPort1.Open()
                btn_online1.BackColor = Color.Lime
                btn_online1.Text = "オンライン"
                Timer2.Enabled = True
            Catch ex As Exception
                MsgBox("Port1 Open Error: " & ex.Message)
            End Try
        End If
    End Sub

    '★★★　PLCリンクデータの表示プログラム　★★★  ----------------------------

    'PLCとのリンクデータ表示／非表示切り替え
    Private Sub btn_monitor_Click(sender As Object, e As EventArgs) Handles btn_monitor.Click
        If lst_read.Visible = True Then
            monitorInvisible()
        Else
            monitorVisible()
        End If
    End Sub

    'PLCとのリンクデータ非表示
    Private Sub monitorInvisible()
        lst_read.Visible = False
        lst_write.Visible = False
        lbl_plcpc.Visible = False
        lbl_pcplc.Visible = False
        lbl_readtop.Visible = False
        lbl_writetop.Visible = False
        lbl_manutest.Text = ""
    End Sub

    'PLCとのリンクデータ表示
    Private Sub monitorVisible()
        lst_read.Visible = True
        lst_write.Visible = True
        lbl_plcpc.Visible = True
        lbl_pcplc.Visible = True
        lbl_readtop.Visible = True
        lbl_writetop.Visible = True
    End Sub

    '★★★　ＰＬＣとの通信プログラム　★★★　MEWTOCOL-COM対応    -------------------------------------------------------------------------------

    Dim plc_num As String = "01"
    Dim sd_code As String = "D"
    Dim rd_code As String = "D"
    Dim rd_top_ad As Integer = 500
    Dim sd_top_ad As Integer = 510
    Dim comDataSize As Integer = 10     'ＰＬＣリンクデータのサイズ

    Dim rd_data(comDataSize - 1) As Short           '受信データ格納用変数
    Dim sd_data(comDataSize - 1) As Short           '送信データ格納用変数
    'Dim sd_data(20) As Short


    'データ送信 comDataSizeワード
    Private Function s_sunxdata() As String

        Dim top_ad, btm_ad As String
        Dim sd_str1, sd_str2, Str As String

        '先頭と最終のワードNoを計算 → 5文字で
        top_ad = Convert.ToString(sd_top_ad)
        top_ad = StrDup(5 - Len(top_ad), "0"c) & top_ad
        btm_ad = Convert.ToString(sd_top_ad + comDataSize - 1) 'comDataSize-1
        btm_ad = StrDup(5 - Len(btm_ad), "0"c) & btm_ad

        'データライト時の送信データ作成
        sd_str1 = "%" & plc_num & "#WD" & sd_code & top_ad & btm_ad
        For i = 0 To comDataSize - 1
            Str = Convert.ToString(sd_data(i), 16)
            If Len(Str) < 4 Then
                Str = StrDup(4 - Len(Str), "0"c) & Str
            ElseIf Len(Str) > 4 Then
                'Str = Str.Substring(4)         'どちらでもよい（４文字目までをカット）
                Str = Strings.Right(Str, 4)     'どちらでもよい（右から４文字を抽出）
            End If
            sd_str1 = sd_str1 & swap(Str)
        Next
        sd_str1 = sd_str1.ToUpper         '大文字変換
        sd_str1 = sd_str1 & bcc(sd_str1)   'BCC付与

        Try
            SerialPort1.Write(sd_str1 & vbCr)
        Catch ex As Exception
            'MsgBox("SerialPort Send Timeout-1 !")
            Return "SerialPort Send Timeout-1 !"
        End Try

        Try
            sd_str2 = SerialPort1.ReadTo(vbCr)
        Catch ex As Exception
            'MsgBox("SerialPort Receive Timeout-1 !")
            Return "SerialPort Receive Timeout-1 !"
        End Try

        If Len(sd_str2) <> 8 Then
            MsgBox("SerialPort WD response data size error " & Len(sd_str2))
        ElseIf Mid(sd_str2, 5, 2) <> "WD" Then
            MsgBox("SerialPort WD response error No." & Mid(sd_str2, 5, 2))
        End If

        Return sd_str1 & vbCrLf & sd_str2
    End Function

    'データ受信 comDataSizeワード
    Private Function r_sunxdata() As String
        Dim i As Integer

        Dim rd_str1, rd_str2 As String
        Dim top_ad, btm_ad As String

        '先頭と最終のワードNoを計算 → 5文字で
        top_ad = Convert.ToString(rd_top_ad)
        top_ad = StrDup(5 - Len(top_ad), "0"c) & top_ad
        btm_ad = Convert.ToString(rd_top_ad + comDataSize - 1)
        btm_ad = StrDup(5 - Len(btm_ad), "0"c) & btm_ad

        'データリード時の送信データ作成
        rd_str1 = "%" & plc_num & "#RD" & rd_code & top_ad & btm_ad
        rd_str1 = rd_str1.ToUpper         '大文字変換
        rd_str1 = rd_str1 & bcc(rd_str1)   'BCC付与

        Try
            SerialPort1.Write(rd_str1 & vbCr)
        Catch ex As Exception
            MsgBox("SerialPort Send Timeout-2 !" & rd_str1)
            Return "SerialPort Send Timeout-2 !"
        End Try

        Try
            rd_str2 = SerialPort1.ReadTo(vbCr)
        Catch ex As Exception
            'MsgBox("SerialPort Receive Timeout-2 !")
            Return "SerialPort Receive Timeout-2 !"
        End Try

        '読み出しデータのチェック　　データサイズとBCCをチェック
        If Len(rd_str2) <> (comDataSize * 4 + 8) Then
            'MsgBox("SerialPort RD response data size error " & Len(rd_str2))
            Return "SerialPort RD response data size error " & Len(rd_str2)
        ElseIf Mid(rd_str2, 5, 2) <> "RD" Then
            'MsgBox("SerialPort RD response error No." & Mid(rd_str2, 5, 2))
            Return "SerialPort RD response error No." & Mid(rd_str2, 5, 2)
        ElseIf Mid(rd_str2, comDataSize * 4 + 7, 2) <> bcc(Mid(rd_str2, 1, comDataSize * 4 + 6)) Then
            MsgBox("SerialPort RD response bcc error ")
            Return "SerialPort RD response bcc error "
        End If

        'データ読込
        For i = 0 To comDataSize - 1
            rd_data(i) = Convert.ToInt16(swap(Mid(rd_str2, 7 + i * 4, 4)), 16)
        Next

        Return rd_str1 & vbCrLf & rd_str2
    End Function

    'BCC計算
    Private Function bcc(ByVal str As String) As String
        Dim tmp As Integer = 0
        Dim tmp_u, tmp_l As Integer
        Dim i As Integer

        For i = 1 To Len(str)
            tmp = tmp Xor Asc(Strings.Mid(str, i, 1))
        Next
        tmp = tmp And &HFF
        tmp_u = (tmp >> 4) + &H30
        If tmp_u > &H39 Then tmp_u = tmp_u + 7
        tmp_l = (tmp And &HF) + &H30
        If tmp_l > &H39 Then tmp_l = tmp_l + 7
        Return Chr(tmp_u) & Chr(tmp_l)
    End Function

    '4文字の上位・下位入れ替え
    Private Function swap(ByVal dt As String) As String
        Dim up, lw As String
        lw = Strings.Right(dt, 2)
        up = Strings.Left(dt, 2)
        Return lw & up
    End Function

    'ＰＬＣとのリンクエリアを０クリア
    Private Sub comDataInit()
        Dim i As Integer

        For i = 0 To comDataSize - 1
            rd_data(i) = 0      'ＰＬＣからの読出しエリア０クリア
            sd_data(i) = 0      'ＰＬＣへの書き込みエリアの０クリア
        Next
        'For j = 0 To 19
        'sd_data(j) = 0
        'Next
    End Sub

    'ＰＬＣとのデータ送受信
    '
    ' （★参考）Timer.Tickでの実行結果
    '	TimerInterval / BaudRate / 100CountTestResult
    '	10 / 115200 / 35sec
    '	50 / 38400 / 25sec★-----今回のデフォルトとする
    '	100 / 19200 / 43sec
    '	200 / 9600 / 86sec
    ' （★参考）データ送受信に必要なタイミングだけ通信
    '	BaudRate / 100CountTestResult
    '	38400 / 18sec
    '
    Private Sub plcCom()
        r_sunxdata()               'ＰＬＣのデータ読み込み
        For i = 0 To comDataSize - 1
            lst_read.Items(i) = rd_data(i)      'ＰＬＣ読込みエリアのデータをリストボックスに表示
        Next

        s_sunxdata()               'ＰＬＣにデータ書き込み
        For i = 0 To comDataSize - 1
            lst_write.Items(i) = sd_data(i)     'ＰＬＣ書込みエリアのデータをリストボックスに表示
        Next
    End Sub

    'PLCリンクデータの表示用リストボックスの初期化
    '   エリアサイズ分のアイテムを作成し、値を０クリアする
    Private Sub lstReadWriteInit()
        lst_read.Items.Clear()
        lst_write.Items.Clear()

        For i = 0 To comDataSize - 1
            lst_read.Items.Add(0)       'ＰＬＣ読み込みエリアの初期化
            lst_write.Items.Add(0)      'ＰＬＣ書込みエリアの初期化
        Next
        'For j = 0 To 19
        'lst_write.Items.Add(0)
        'Next
    End Sub


    'ＰＬＣとのデータ送受信の実行　Timer2 を使用して一定周期で plcCom() を実行  ------------------------------------------------------------------

    Private Sub timinit2()
        Timer2.Interval = 50    '★もし不具合がでるようであればチューニング
        Timer2.Enabled = False
    End Sub

    '設定されたインターバルでＰＬＣとのデータ送受信を実行
    Private Sub Timer2_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer2.Tick
        If plcComBusyFlag = True Then Exit Sub      '前回のTimer2_Tickでの通信が終了していない場合は以降の処理を行わない

        plcComBusyFlag = True
        plcCom()                                    '★PLCとの送受信★
        plcComBusyFlag = False

    End Sub



    '★★★　デジタルパネルメータ接続用シリアル通信ポートの設定　★★★　Serial.Port2を使用    /////////////////////////////////////////////////

    'デジタルパネルメータ接続ポートの設定用コンボボックスアイテムのデフォルト設定
    Private Sub comboBoxInit2()
        port2_search()
        cmb_port2.SelectedIndex = cmb_port2.Items.Count - 1 'コンボボックス一番下のアイテム
        cmb_baudrate2.SelectedIndex = 0     '9600
        cmb_databits2.SelectedIndex = 0     '7
        cmb_stopbits2.SelectedIndex = 1     '1
        cmb_parity2.SelectedIndex = 2       'Even
    End Sub

    'デジタルパネル接続シリアルポート設定用にCOM番号をリストアップ
    Private Sub port2_search()
        cmb_port2.Items.Clear()
        For Each sp As String In My.Computer.Ports.SerialPortNames
            cmb_port2.Items.Add(sp)   'アイテムを追加
        Next
    End Sub

    '通信ポート設定　マウスクリックでコンボボックスにCOM番号を表示
    Private Sub cmb_port2_click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmb_port2.MouseClick
        port2_search()
    End Sub

    'デジタルパネルメータ接続用シリアルポートの設定
    Private Sub btn_comset2_Click(sender As Object, e As EventArgs) Handles btn_comset2.Click
        If SerialPort2.IsOpen Then
            MsgBox("ポートが開いているので設定変更できませんでした")
            Exit Sub
        End If

        Select Case cmb_baudrate2.SelectedItem
            Case "9600"
                SerialPort2.BaudRate = "9600"
            Case "19200"
                SerialPort2.BaudRate = "19200"
            Case "38400"
                SerialPort2.BaudRate = "38400"
            Case "57600"
                SerialPort2.BaudRate = "57600"
            Case "115200"
                SerialPort2.BaudRate = "115200"
        End Select

        Select Case cmb_databits2.SelectedItem
            Case "7"
                SerialPort2.DataBits = 7
            Case "8"
                SerialPort2.DataBits = 8
        End Select

        Select Case cmb_stopbits2.SelectedItem
            Case "1"
                SerialPort2.StopBits = IO.Ports.StopBits.One
            Case "2"
                SerialPort2.StopBits = IO.Ports.StopBits.Two
        End Select

        Select Case cmb_parity2.SelectedItem
            Case "None"
                SerialPort2.Parity = IO.Ports.Parity.None
            Case "Odd"
                SerialPort2.Parity = IO.Ports.Parity.Odd
            Case "Even"
                SerialPort2.Parity = IO.Ports.Parity.Even
        End Select

        SerialPort2.PortName = cmb_port2.SelectedItem
        SerialPort2.ReadTimeout = 1000
        SerialPort2.WriteTimeout = 1000
    End Sub

    'デジタルパネルメータ接続用のオンライン/オフライン切り替え
    Private Sub btn_online2_Click(sender As Object, e As EventArgs) Handles btn_online2.Click
        If SerialPort2.IsOpen Then
            Try
                SerialPort2.Close()
                btn_online2.BackColor = Color.LightGray
                btn_online2.Text = "オフライン"
            Catch ex As Exception
                MsgBox("Port2 Close Error: " & ex.Message)
            End Try
        Else
            Try
                SerialPort2.Open()
                btn_online2.BackColor = Color.Lime
                btn_online2.Text = "オンライン"
            Catch ex As Exception
                MsgBox("Port2 Open Error: " & ex.Message)
            End Try
        End If
    End Sub


    '★★★　デジタルパネルメータ通信プログラム　★★★　CompoWay/F対応     ------------------------------------------------------------------------

    'OMRON K3HB コマンド送信要素
    Dim NODE As String = "01"       'ノードNo.
    Dim SUB_AD As String = "00"     'サブアドレス（未使用：00を指定）
    Dim SID As String = "0"         'サービスID（未使用：0を指定）
    Dim STX As String = Chr(&H2)    '通信フレームの先頭コード
    Dim ETX As String = Chr(&H3)    'テキストの終了コード
    Dim MRC As String = "01"        'メインリクエストコード（モニタ値読出し：01）
    Dim SRC As String = "01"        'サブリクエストコード（モニタ値読出し：01）
    Dim KIND As String = "C0"       '変数種別（モニタ値読出し：C0）
    Dim ADRS As String = "0002"     'アドレス（計測値：0002）
    Dim BIT As String = "00"        'ビット位置（00）
    Dim ITEM As String = "0001"     '要素数（0001）

    'ブロックチェックキャラクタ計算（CompoWay/F）　ノードNoからETXまでのBCCを計算
    Private Function bcc_omron(ByVal dt As String) As String
        Dim i As Integer
        Dim bcc As Integer = &H0

        For i = 2 To Len(dt)
            bcc = bcc Xor Asc(Mid(dt, i, 1))
        Next
        Return Chr(bcc)

    End Function

    'データライト sd_sizeワード
    Private Function s_omrondata() As Single

        Dim CMD, CMD_TXT As String
        Dim sd_str As String

        CMD = KIND & ADRS & BIT & ITEM
        CMD_TXT = MRC & SRC & CMD
        sd_str = STX & NODE & SUB_AD & SID & CMD_TXT & ETX
        sd_str = sd_str & bcc_omron(sd_str)

        Try
            SerialPort2.Write(sd_str)
        Catch ex As Exception
            MsgBox("SerialPort Send Error: " & ex.Message)
            Return -1000   '例外発生
        End Try
        Return 0

    End Function

    'データリード rd_sizeワード
    Private Function r_omrondata() As Single

        Dim rcv_str As String
        Dim rcv_val As Single
        Dim r_node, r_subAdrs, r_MRC, r_SRC, r_endCode, r_ResCode, r_data As String

        Try
            timset(100)
            Do Until SerialPort2.BytesToRead = 25
                Application.DoEvents()
                If timchk() = 0 Then
                    MsgBox("SerialPort Receive Timeout !")
                    rcv_str = SerialPort2.ReadExisting()
                    Return -1002   '受信データタイムアウト（受信バイト数不足）
                End If
            Loop

            rcv_str = SerialPort2.ReadExisting()

        Catch ex As Exception
            MsgBox("SerialPort Receive Error: " & ex.Message)
            Return -1001   '例外発生
        End Try

        r_node = Mid(rcv_str, 2, 2)         '受信データよりノードNo取出し
        r_subAdrs = Mid(rcv_str, 4, 2)      '受信データよりサブアドレス取出し
        r_endCode = Mid(rcv_str, 6, 2)      '受信データより終了コード取出し
        r_MRC = Mid(rcv_str, 8, 2)          '受信データよりMRC取出し
        r_SRC = Mid(rcv_str, 10, 2)         '受信データよりSRC取出し
        r_ResCode = Mid(rcv_str, 12, 4)     '受信データよりレスポンスコード取出し
        r_data = Mid(rcv_str, 16, 8)        '受信データより計測データ取出し

        'txt_rcvstr.Text = txt_rcvstr.Text & rcv_str & vbCrLf    '受信データ表示

        '受信データチェック（正常時は、終了コード="00"、レスポンスコード="0000"）
        If (r_endCode <> "00") Or (r_ResCode <> "0000") Then
            MsgBox("SerialPort Receive Error  EndCode:" & r_endCode & ", ResCode:" & r_ResCode)
            Return -1003   '異常レスポンスあり
        End If

        '測定データの値への変換　　16進数の文字列を整数にコンバート後、桁数を合わせてSingleに
        rcv_val = Convert.ToInt32(r_data, 16) / 100
        'txt_rcvval.Text = txt_rcvval.Text & rcv_val & vbCrLf

        Return rcv_val

    End Function

    'マニュアル測定
    Private Sub bnt_test_Click(sender As Object, e As EventArgs) Handles bnt_test.Click
        Dim result As Single

        lbl_manutest.Text = ""

        If SerialPort2.IsOpen Then
            result = s_omrondata()      'コマンド送信
            If result <> 0 Then
                lbl_manutest.Text = "Send Error"
                Exit Sub
            End If
            result = r_omrondata()      'レスポンス受信
            If result < -1000 Then
                lbl_manutest.Text = "Receive Error"
            Else
                lbl_manutest.Text = Format(result, "0.00")
            End If
        End If
    End Sub



    ' ★★★　主要なアプリケーションプログラム　★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★

    'フォームロード
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        timinit()               'Timer1の初期化　　汎用

        timinit2()              'Timer2の初期化　　PLCとのデータ送受信用
        lstReadWriteInit()      'PLCリンクデータ表示用リストボックスを初期化
        monitorInvisible()      'PLCリンクデータ表示用リストボックスを非表示
        comboBoxInit1()         'PLCリンク用シリアルポート（Serial.Port1）の設定用コンボボックスにデフォルトを設定

        comboBoxInit2()         'デジタルパネルメータ接続用シリアルポート（Serial.Port2）の設定用コンボボックスにデフォルトを設定

        Label3.Visible = False

        dataCount = 0

        If Not IsNumeric(txt_uplimit.Text) Or Not IsNumeric(txt_lowlimit.Text) Then
            MsgBox("Please always input number on UP and LOW Limit... !!")
            Exit Sub
        End If

        'show cycle time
        Timer3.Enabled = True
    End Sub

    Private Sub btn_start_Click(sender As Object, e As EventArgs) Handles btn_start_batch.Click
        Dim result As Double
        Dim i, k As Integer

        lbl_manutest.Text = ""

        While True

            Application.DoEvents()

            Select Case rd_data(0)
                Case 99
                    lst_result.Items.Clear()
                    lst_maxmin.Items.Clear()
                    lst_judge.Items.Clear()
                    lst_No.Items.Clear()
                    lst_rank.Items.Clear()
                    For k = 3 To 7
                        sd_data(k) = 0
                    Next
                    i = 0
                Case 0
                    sd_data(0) = 0
                    sd_data(5) = 0
                Case 1
                    'If rd_data(0) = 1 Then
                    If SerialPort2.IsOpen And sd_data(0) = 0 Then

                        result = s_omrondata()      'コマンド送信
                        If result <> 0 Then
                            Label3.Visible = True
                            Label3.Text = "Send Error"
                            Exit Sub
                        End If
                        result = 0 - r_omrondata()      'レスポンス受信
                        If result < 0 Then
                            Label3.Visible = True
                            Label3.Text = "Receive Error"
                        Else
                            '===LIST NO==='
                            lst_No.Items.Add(i + 1)

                            'RESULT CHECK'
                            lst_result.Items.Add(Format(result, "0.00"))
                            sd_data(0) = 1
                            i += 1

                            Select Case i
                                Case 1
                                    sd_data(5) = 4
                                    sd_data(7) = result * 100
                                    timwait(10)
                                Case 2
                                    sd_data(5) = 5
                                    sd_data(7) = result * 100
                                    timwait(10)
                                Case 3
                                    sd_data(5) = 6
                                    sd_data(7) = result * 100
                                    timwait(10)
                            End Select

                            '===JUDGE OK or NG==='
                            If result >= Val(txt_lowlimit.Text) And result <= Val(txt_uplimit.Text) Then
                                lst_judge.Items.Add("OK")
                                list_judgement.Items.Add("OK")
                                sd_data(1) = 2
                                timer_dt1.Enabled = True
                            Else
                                lst_judge.Items.Add("NG")
                                list_judgement.Items.Add("NG")
                                sd_data(1) = 1
                                timer_dt1.Enabled = True
                            End If

                            update_data_result()

                            '---- UPDATE 生産のデータ ----'
                            list_no.Items.Add(dataCount + 1)
                            list_datetime.Items.Add(Format(Now, "yyyy/MM/dd HH:mm:ss"))
                            list_result.Items.Add(Format(result, "0.00"))
                            list_uplimit.Items.Add(Val(txt_uplimit.Text))
                            list_lowlimit.Items.Add(Val(txt_lowlimit.Text))
                            dataCount = dataCount + 1

                        End If
                    End If

            End Select

            If rd_data(9) = 0 Then
                btn_start_robot.BackColor = Color.Gainsboro
                k = 0
            End If

        End While
    End Sub

    Private Sub btn_close_Click(sender As Object, e As EventArgs) Handles btn_close.Click

        sd_data(2) = 0
        timwait(20)
        SerialPort1.Close()
        SerialPort2.Close()

        End
    End Sub

    Private Sub Timer3_Tick(sender As Object, e As EventArgs) Handles Timer3.Tick
        lbl_cycletime.Text = Val(rd_data(1)) / 10
        Select Case rd_data(2)
            Case 0
                lbl_control.Text = "Waiting for control..."
                lbl_automaualvb.Text = ""
            Case 11
                lbl_control.Text = "Main Control : PANEL BOX"
            Case 22
                lbl_control.Text = "Main Control : Touch Panel"
            Case 33
                lbl_control.Text = "Main Control : VB Program"
        End Select

        If rd_data(8) = 1 Then
            sd_data(9) = rd_data(6)
            sd_data(8) = rd_data(7)
            txt_uplimit.Text = Format(sd_data(9) / 100, "0.00")
            txt_lowlimit.Text = Format(sd_data(8) / 100, "0.00")

        Else
            sd_data(9) = Format(Val(txt_uplimit.Text) * 100, "0.00")
            sd_data(8) = Format(Val(txt_lowlimit.Text) * 100, "0.00")
        End If

        lbl_xpos.Text = rd_data(3)
        lbl_ypos.Text = rd_data(4)
        lbl_zpos.Text = rd_data(5)

    End Sub

    Private Sub timer_dt4_Tick(sender As Object, e As EventArgs) Handles timer_dt4.Tick
        Dim i As Integer
        For i = 0 To 100
            Application.DoEvents()
        Next
        sd_data(4) = 0
        timer_dt4.Enabled = False
        btn_stop_robot.BackColor = Color.Gainsboro
        btn_stop_robot.ForeColor = Color.Black
    End Sub

    Private Sub update_data(sender As Object, e As EventArgs) Handles lst_result.DataSourceChanged, lst_judge.DataSourceChanged, lst_No.DataSourceChanged

    End Sub

    Private Sub update_data_result()
        Dim sum, max, min, ave As Double
        Dim i, j, k, x, y, z As Integer
        i = 0
        j = 0
        k = 0

        sum = 0

        If lst_result.Items.Count <> 0 Then

            '====COUNT max,min,ave===='
            For i = 0 To lst_result.Items.Count - 1
                sum = lst_result.Items(i)
                If min = 0 Then
                    min = sum
                    sd_data(5) = 2
                    sd_data(7) = min * 100
                    timwait(10)
                End If

                If sum >= max Then
                    max = sum
                    sd_data(5) = 1
                    sd_data(7) = max * 100
                    timwait(10)
                Else
                    min = sum
                    sd_data(5) = 2
                    sd_data(7) = min * 100
                    timwait(10)
                End If
                ave = Format(ave + sum, "0.00")

                'RANK DATA'
                lst_rank.Items.Clear()
                x = 1 'rank data 1
                y = 1 'rank data 2
                z = 1 'rank data 3
                Select Case i
                    Case 0
                        lst_rank.Items.Insert(0, x)
                        sd_data(5) = 7
                        sd_data(7) = x
                        timwait(10)
                    Case 1
                        If lst_result.Items(0) < lst_result.Items(1) Then x = x + 1
                        If lst_result.Items(1) < lst_result.Items(0) Then y = y + 1
                        lst_rank.Items.Insert(0, x)
                        sd_data(5) = 7
                        sd_data(7) = x
                        timwait(10)
                        lst_rank.Items.Insert(1, y)
                        sd_data(5) = 8
                        sd_data(7) = y
                        timwait(10)
                    Case 2
                        If lst_result.Items(0) < lst_result.Items(1) Then x = x + 1
                        If lst_result.Items(0) < lst_result.Items(2) Then x = x + 1
                        If lst_result.Items(1) < lst_result.Items(0) Then y = y + 1
                        If lst_result.Items(1) < lst_result.Items(2) Then y = y + 1
                        If lst_result.Items(2) < lst_result.Items(0) Then z = z + 1
                        If lst_result.Items(2) < lst_result.Items(1) Then z = z + 1
                        lst_rank.Items.Insert(0, x)
                        sd_data(5) = 7
                        sd_data(7) = x
                        timwait(10)
                        lst_rank.Items.Insert(1, y)
                        sd_data(5) = 8
                        sd_data(7) = y
                        timwait(10)
                        lst_rank.Items.Insert(2, z)
                        sd_data(5) = 9
                        sd_data(7) = z
                        timwait(10)
                End Select
            Next

            Select Case i
                Case 0
                    ave = ave / 1
                    sd_data(5) = 3
                    sd_data(7) = ave * 100
                    timwait(10)
                Case <> 0
                    ave = ave / i
                    sd_data(5) = 3
                    sd_data(7) = ave * 100
                    timwait(10)
            End Select

            '====SHOW DATA MAX MIN TO LIST BOX===='
            lst_maxmin.Items.Clear()
            lst_maxmin.Items.Insert(0, Format(max, "0.00"))
            lst_maxmin.Items.Insert(1, Format(min, "0.00"))
            lst_maxmin.Items.Insert(2, Format(ave, "0.00"))


            'lst_rank.DataSource = (From L In lst_result.Items() Select L Order By L Ascending).ToList

        End If
    End Sub
    Private Sub updatedataPLC()
        Dim k As Integer
        k = 0

        For k = 0 To lst_result.Items.Count - 1
            'spec up low
            'sd_data(9) = Val(txt_uplimit.Text) * 100
            'sd_data(10) = Val(txt_lowlimit.Text) * 100

            'PIN Result
            If k = 0 Then sd_data(14) = lst_result.Items(0) * 100
            If k = 1 Then sd_data(15) = lst_result.Items(1) * 100
            If k = 2 Then sd_data(16) = lst_result.Items(2) * 100
            'max,min,ave
            sd_data(11) = lst_maxmin.Items(0) * 100
            sd_data(12) = lst_maxmin.Items(1) * 100
            sd_data(13) = lst_maxmin.Items(2) * 100

            'PIN Rank
            If k = 0 Then sd_data(17) = lst_rank.Items(0)
            If k = 1 Then sd_data(18) = lst_rank.Items(1)
            If k = 2 Then sd_data(19) = lst_rank.Items(2)
        Next


    End Sub
    Private Sub clear_lst(sender As Object, e As EventArgs) Handles MyBase.Click
        lst_maxmin.SelectedIndex() = -1
        lst_result.SelectedIndex() = -1
        lst_read.SelectedIndex() = -1
        lst_write.SelectedIndex() = -1
        lst_No.SelectedIndex() = -1
        list_no.SelectedIndex() = -1
        list_datetime.SelectedIndex() = -1
        list_result.SelectedIndex() = -1
        list_lowlimit.SelectedIndex() = -1
        list_uplimit.SelectedIndex() = -1
        list_judgement.SelectedIndex() = -1
        txt_lowlimit.Select(0, 0)
        txt_uplimit.Select(0, 0)
    End Sub
    Private Sub btn_auto_Click(sender As Object, e As EventArgs) Handles btn_auto.Click
        'sd_data(3) = 1
        If lbl_control.Text = "Main Control : VB Program" Then
            sd_data(3) = 1
            lbl_automaualvb.Text = "VB : AUTO"
        Else
            lbl_automaualvb.Text = "-----------"
        End If
    End Sub

    Private Sub btn_manual_Click(sender As Object, e As EventArgs) Handles btn_manual.Click
        If lbl_control.Text = "Main Control : VB Program" Then
            lbl_automaualvb.Text = "VB : MANUAL"
            sd_data(3) = 0
            sd_data(4) = 99
            timwait(10)
            sd_data(4) = 0
        Else
            lbl_automaualvb.Text = "-----------"
        End If
    End Sub
    Private Sub btn_origin_Click(sender As Object, e As EventArgs) Handles btn_origin.Click
        If sd_data(4) = 0 Then
            sd_data(4) = 1
            btn_origin.BackColor = Color.Lime
        ElseIf sd_data(4) = 1 Then
            sd_data(4) = 0
            btn_origin.BackColor = Color.Gainsboro
        End If
    End Sub

    Private Sub btn_start_robot_Click(sender As Object, e As EventArgs) Handles btn_start_robot.Click
        btn_start_robot.BackColor = Color.Lime
        sd_data(4) = 2
        timer_dt4.Enabled = True
        btn_start_batch.PerformClick()
    End Sub

    Private Sub btn_stop_robot_Click(sender As Object, e As EventArgs) Handles btn_stop_robot.Click
        btn_stop_robot.BackColor = Color.Red
        btn_stop_robot.ForeColor = Color.White
        sd_data(4) = 99
        timer_dt4.Enabled = True
    End Sub


    Private Sub btn_save_Click(sender As Object, e As EventArgs) Handles btn_save.Click
        Call writeCSV()
    End Sub

    Private Sub btn_cleardata_Click(sender As Object, e As EventArgs) Handles btn_cleardata.Click

        list_no.Items.Clear()
        list_datetime.Items.Clear()
        list_result.Items.Clear()
        list_lowlimit.Items.Clear()
        list_uplimit.Items.Clear()
        list_judgement.Items.Clear()
        dataCount = 0

    End Sub

    Private Sub chuck_open_Click(sender As Object, e As EventArgs) Handles chuck_open.Click
        If sd_data(4) <> 10 Then
            sd_data(4) = 10
            chuck_open.Text = "Chuck Close"
        ElseIf sd_data(4) = 10 Then
            sd_data(4) = 0
            chuck_open.Text = "Chuck Open"
        End If

    End Sub

    Private Sub timer_dt1_Tick(sender As Object, e As EventArgs) Handles timer_dt1.Tick
        Dim i As Integer

        For i = 0 To 100
            Application.DoEvents()
        Next

        sd_data(1) = 0
    End Sub

    Private Sub timer_dt2_Tick(sender As Object, e As EventArgs) Handles timer_dt2.Tick
        Dim i As Integer
        For i = 0 To 1000
            Application.DoEvents()
        Next
        sd_data(2) = 0
        timer_dt2.Enabled = False
    End Sub

    Private Sub writeCSV()
        Dim no, count As Integer
        Dim datetime, judge As String
        Dim result, lowlimit, uplimit As Double
        Dim fname As String

        SaveFileCSV.Filter = "CSV File |*.csv"
        SaveFileCSV.ShowDialog()
        If SaveFileCSV.FileName <> "" Then
            fname = SaveFileCSV.FileName
        Else
            Exit Sub
        End If

        Dim writer As New IO.StreamWriter(fname, False, System.Text.Encoding.UTF8)
        writer.WriteLine("No,Date_and_Time,Result,UP_Limit,Low_Limit,Judgement")
        For count = 0 To list_no.Items.Count - 1
            no = list_no.Items(count)
            datetime = list_datetime.Items(count)
            result = list_result.Items(count)
            uplimit = list_uplimit.Items(count)
            lowlimit = list_lowlimit.Items(count)
            judge = list_judgement.Items(count)
            writer.WriteLine(no & "," & datetime & "," & result & "," & uplimit & "," & lowlimit & "," & judge)
        Next
        writer.Close()
        Shell(Exl & fname, AppWinStyle.MaximizedFocus)
    End Sub

    Private Sub testbutton_Click(sender As Object, e As EventArgs) Handles testbutton.Click
        Dim i As Integer
        Dim t As Integer
        Dim uplimit, lowlimit As Double
        Dim random As New System.Random()

        uplimit = Val(txt_uplimit.Text)
        lowlimit = Val(txt_lowlimit.Text)

        If SerialPort1.IsOpen Then sd_data(19) = 99

        If Not SerialPort1.IsOpen Or Not SerialPort2.IsOpen Then

            For i = 0 To 19
                list_no.Items.Add(i + 1)
                list_datetime.Items.Add(Format(Now, "yyyy/MM/dd HH:mm:ss"))
                list_result.Items.Add(random.Next(lowlimit * 0.85, uplimit / 0.85))
                list_uplimit.Items.Add(uplimit)
                list_lowlimit.Items.Add(lowlimit)
                If Val(list_result.Items(i)) <= uplimit And Val(list_result.Items(i)) >= lowlimit Then
                    list_judgement.Items.Add("OK")
                Else
                    list_judgement.Items.Add("NG")
                End If

                t = 200
                While t > 0
                    Application.DoEvents()
                    t -= 1
                End While
            Next
        End If
    End Sub

    Private Sub btn_x1_Click(sender As Object, e As EventArgs) Handles btn_x1.Click
        sd_data(6) = 1
    End Sub

    Private Sub btn_x2_Click(sender As Object, e As EventArgs) Handles btn_x2.Click
        sd_data(6) = 2
    End Sub

    Private Sub btn_x3_Click(sender As Object, e As EventArgs) Handles btn_x3.Click
        sd_data(6) = 3
    End Sub

    Private Sub btn_x4_Click(sender As Object, e As EventArgs) Handles btn_x4.Click
        sd_data(6) = 4
    End Sub

    Private Sub btn_x5_Click(sender As Object, e As EventArgs) Handles btn_x5.Click
        sd_data(6) = 5
    End Sub

    Private Sub btn_x0_Click(sender As Object, e As EventArgs) Handles btn_x0.Click
        sd_data(6) = 100
    End Sub

    Private Sub btn_y1_Click(sender As Object, e As EventArgs) Handles btn_y1.Click
        sd_data(6) = 6
    End Sub

    Private Sub btn_y2_Click(sender As Object, e As EventArgs) Handles btn_y2.Click
        sd_data(6) = 7
    End Sub

    Private Sub btn_y3_Click(sender As Object, e As EventArgs) Handles btn_y3.Click
        sd_data(6) = 8
    End Sub

    Private Sub btn_y4_Click(sender As Object, e As EventArgs) Handles btn_y4.Click
        sd_data(6) = 9
    End Sub

    Private Sub btn_y5_Click(sender As Object, e As EventArgs) Handles btn_y5.Click
        sd_data(6) = 10
    End Sub

    Private Sub btn_y0_Click(sender As Object, e As EventArgs) Handles btn_y0.Click
        sd_data(6) = 200
    End Sub

    Private Sub btn_z1_Click(sender As Object, e As EventArgs) Handles btn_z1.Click
        sd_data(6) = 11
    End Sub

    Private Sub btn_z2_Click(sender As Object, e As EventArgs) Handles btn_z2.Click
        sd_data(6) = 12
    End Sub

    Private Sub btn_z3_Click(sender As Object, e As EventArgs) Handles btn_z3.Click
        sd_data(6) = 13
    End Sub

    Private Sub btn_z4_Click(sender As Object, e As EventArgs) Handles btn_z4.Click
        sd_data(6) = 14
    End Sub

    Private Sub btn_z5_Click(sender As Object, e As EventArgs) Handles btn_z5.Click
        sd_data(6) = 15
    End Sub

    Private Sub btn_z0_Click(sender As Object, e As EventArgs) Handles btn_z0.Click
        sd_data(6) = 300
    End Sub

    Private Sub uplimitchange(sender As Object, e As EventArgs) Handles txt_uplimit.TextChanged
        If Not IsNumeric(txt_uplimit.Text) Then
            MsgBox("Please input number at UP LIMIT !!")
            txt_uplimit.Text = Val(txt_lowlimit.Text)
            Exit Sub
        End If
    End Sub

    Private Sub lowlimitchange(sender As Object, e As EventArgs) Handles txt_lowlimit.TextChanged
        If Not IsNumeric(txt_lowlimit.Text) Then
            MsgBox("Please input number at LOW LIMIT !!")
            txt_lowlimit.Text = Val(txt_uplimit.Text)
            Exit Sub
        End If
    End Sub


End Class
