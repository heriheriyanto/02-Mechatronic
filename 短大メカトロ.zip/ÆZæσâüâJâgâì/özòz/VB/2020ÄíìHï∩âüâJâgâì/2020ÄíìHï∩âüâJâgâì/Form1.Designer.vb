﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.lbl_title = New System.Windows.Forms.Label()
        Me.lbl_comset1 = New System.Windows.Forms.Label()
        Me.lbl_comset2 = New System.Windows.Forms.Label()
        Me.lbl_port = New System.Windows.Forms.Label()
        Me.lbl_baudrate = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.cmb_port1 = New System.Windows.Forms.ComboBox()
        Me.cmb_baudrate1 = New System.Windows.Forms.ComboBox()
        Me.cmb_stopbits1 = New System.Windows.Forms.ComboBox()
        Me.cmb_parity1 = New System.Windows.Forms.ComboBox()
        Me.cmb_port2 = New System.Windows.Forms.ComboBox()
        Me.cmb_baudrate2 = New System.Windows.Forms.ComboBox()
        Me.cmb_stopbits2 = New System.Windows.Forms.ComboBox()
        Me.cmb_parity2 = New System.Windows.Forms.ComboBox()
        Me.btn_comset1 = New System.Windows.Forms.Button()
        Me.btn_comset2 = New System.Windows.Forms.Button()
        Me.btn_online1 = New System.Windows.Forms.Button()
        Me.btn_online2 = New System.Windows.Forms.Button()
        Me.bnt_test = New System.Windows.Forms.Button()
        Me.btn_monitor = New System.Windows.Forms.Button()
        Me.lbl_manutest = New System.Windows.Forms.Label()
        Me.lbl_plcpc = New System.Windows.Forms.Label()
        Me.lbl_pcplc = New System.Windows.Forms.Label()
        Me.lst_read = New System.Windows.Forms.ListBox()
        Me.lst_write = New System.Windows.Forms.ListBox()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.SerialPort1 = New System.IO.Ports.SerialPort(Me.components)
        Me.SerialPort2 = New System.IO.Ports.SerialPort(Me.components)
        Me.lbl_readtop = New System.Windows.Forms.Label()
        Me.lbl_writetop = New System.Windows.Forms.Label()
        Me.lbl_databits = New System.Windows.Forms.Label()
        Me.cmb_databits1 = New System.Windows.Forms.ComboBox()
        Me.cmb_databits2 = New System.Windows.Forms.ComboBox()
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.btn_start_batch = New System.Windows.Forms.Button()
        Me.btn_close = New System.Windows.Forms.Button()
        Me.Timer3 = New System.Windows.Forms.Timer(Me.components)
        Me.lst_result = New System.Windows.Forms.ListBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.lst_maxmin = New System.Windows.Forms.ListBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.txt_uplimit = New System.Windows.Forms.TextBox()
        Me.txt_lowlimit = New System.Windows.Forms.TextBox()
        Me.timer_dt4 = New System.Windows.Forms.Timer(Me.components)
        Me.lst_judge = New System.Windows.Forms.ListBox()
        Me.lst_No = New System.Windows.Forms.ListBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.lbl_cycletime = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.lst_rank = New System.Windows.Forms.ListBox()
        Me.Rank = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.lbl_zpos = New System.Windows.Forms.Label()
        Me.lbl_ypos = New System.Windows.Forms.Label()
        Me.lbl_xpos = New System.Windows.Forms.Label()
        Me.lbl_automaualvb = New System.Windows.Forms.Label()
        Me.lbl_control = New System.Windows.Forms.Label()
        Me.btn_z0 = New System.Windows.Forms.Button()
        Me.btn_z5 = New System.Windows.Forms.Button()
        Me.btn_z4 = New System.Windows.Forms.Button()
        Me.btn_z3 = New System.Windows.Forms.Button()
        Me.btn_z2 = New System.Windows.Forms.Button()
        Me.btn_z1 = New System.Windows.Forms.Button()
        Me.btn_y0 = New System.Windows.Forms.Button()
        Me.btn_y5 = New System.Windows.Forms.Button()
        Me.btn_y4 = New System.Windows.Forms.Button()
        Me.btn_y3 = New System.Windows.Forms.Button()
        Me.btn_y2 = New System.Windows.Forms.Button()
        Me.btn_y1 = New System.Windows.Forms.Button()
        Me.btn_x0 = New System.Windows.Forms.Button()
        Me.btn_x5 = New System.Windows.Forms.Button()
        Me.btn_x4 = New System.Windows.Forms.Button()
        Me.btn_x3 = New System.Windows.Forms.Button()
        Me.btn_x2 = New System.Windows.Forms.Button()
        Me.btn_x1 = New System.Windows.Forms.Button()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.btn_manual = New System.Windows.Forms.Button()
        Me.btn_auto = New System.Windows.Forms.Button()
        Me.chuck_open = New System.Windows.Forms.Button()
        Me.btn_stop_robot = New System.Windows.Forms.Button()
        Me.btn_start_robot = New System.Windows.Forms.Button()
        Me.btn_origin = New System.Windows.Forms.Button()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.list_judgement = New System.Windows.Forms.ListBox()
        Me.list_lowlimit = New System.Windows.Forms.ListBox()
        Me.list_uplimit = New System.Windows.Forms.ListBox()
        Me.list_result = New System.Windows.Forms.ListBox()
        Me.list_datetime = New System.Windows.Forms.ListBox()
        Me.list_no = New System.Windows.Forms.ListBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.timer_dt1 = New System.Windows.Forms.Timer(Me.components)
        Me.timer_dt2 = New System.Windows.Forms.Timer(Me.components)
        Me.btn_save = New System.Windows.Forms.Button()
        Me.btn_cleardata = New System.Windows.Forms.Button()
        Me.SaveFileCSV = New System.Windows.Forms.SaveFileDialog()
        Me.testbutton = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.SuspendLayout()
        '
        'lbl_title
        '
        Me.lbl_title.AutoSize = True
        Me.lbl_title.Font = New System.Drawing.Font("MS UI Gothic", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lbl_title.Location = New System.Drawing.Point(404, 9)
        Me.lbl_title.Name = "lbl_title"
        Me.lbl_title.Size = New System.Drawing.Size(392, 33)
        Me.lbl_title.TabIndex = 0
        Me.lbl_title.Text = "【 2020 治工具応用メカトロ 】"
        '
        'lbl_comset1
        '
        Me.lbl_comset1.AutoSize = True
        Me.lbl_comset1.Location = New System.Drawing.Point(42, 121)
        Me.lbl_comset1.Name = "lbl_comset1"
        Me.lbl_comset1.Size = New System.Drawing.Size(61, 12)
        Me.lbl_comset1.TabIndex = 2
        Me.lbl_comset1.Text = "パネルメータ"
        '
        'lbl_comset2
        '
        Me.lbl_comset2.AutoSize = True
        Me.lbl_comset2.Location = New System.Drawing.Point(42, 96)
        Me.lbl_comset2.Name = "lbl_comset2"
        Me.lbl_comset2.Size = New System.Drawing.Size(50, 12)
        Me.lbl_comset2.TabIndex = 3
        Me.lbl_comset2.Text = "PLCリンク"
        '
        'lbl_port
        '
        Me.lbl_port.AutoSize = True
        Me.lbl_port.Location = New System.Drawing.Point(136, 76)
        Me.lbl_port.Name = "lbl_port"
        Me.lbl_port.Size = New System.Drawing.Size(30, 12)
        Me.lbl_port.TabIndex = 2
        Me.lbl_port.Text = "COM"
        '
        'lbl_baudrate
        '
        Me.lbl_baudrate.AutoSize = True
        Me.lbl_baudrate.Location = New System.Drawing.Point(197, 76)
        Me.lbl_baudrate.Name = "lbl_baudrate"
        Me.lbl_baudrate.Size = New System.Drawing.Size(52, 12)
        Me.lbl_baudrate.TabIndex = 2
        Me.lbl_baudrate.Text = "ボーレート"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(336, 76)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(61, 12)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "ストップビット"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(417, 76)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(38, 12)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "パリティ"
        '
        'cmb_port1
        '
        Me.cmb_port1.FormattingEnabled = True
        Me.cmb_port1.Location = New System.Drawing.Point(115, 91)
        Me.cmb_port1.Name = "cmb_port1"
        Me.cmb_port1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmb_port1.Size = New System.Drawing.Size(68, 20)
        Me.cmb_port1.TabIndex = 4
        '
        'cmb_baudrate1
        '
        Me.cmb_baudrate1.FormattingEnabled = True
        Me.cmb_baudrate1.Items.AddRange(New Object() {"9600", "19200", "38400", "57600", "115200"})
        Me.cmb_baudrate1.Location = New System.Drawing.Point(186, 91)
        Me.cmb_baudrate1.Name = "cmb_baudrate1"
        Me.cmb_baudrate1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmb_baudrate1.Size = New System.Drawing.Size(68, 20)
        Me.cmb_baudrate1.TabIndex = 4
        '
        'cmb_stopbits1
        '
        Me.cmb_stopbits1.FormattingEnabled = True
        Me.cmb_stopbits1.Items.AddRange(New Object() {"1", "2"})
        Me.cmb_stopbits1.Location = New System.Drawing.Point(329, 91)
        Me.cmb_stopbits1.Name = "cmb_stopbits1"
        Me.cmb_stopbits1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmb_stopbits1.Size = New System.Drawing.Size(68, 20)
        Me.cmb_stopbits1.TabIndex = 4
        '
        'cmb_parity1
        '
        Me.cmb_parity1.FormattingEnabled = True
        Me.cmb_parity1.Items.AddRange(New Object() {"None", "Odd", "Even"})
        Me.cmb_parity1.Location = New System.Drawing.Point(401, 91)
        Me.cmb_parity1.Name = "cmb_parity1"
        Me.cmb_parity1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmb_parity1.Size = New System.Drawing.Size(68, 20)
        Me.cmb_parity1.TabIndex = 4
        '
        'cmb_port2
        '
        Me.cmb_port2.FormattingEnabled = True
        Me.cmb_port2.Location = New System.Drawing.Point(115, 117)
        Me.cmb_port2.Name = "cmb_port2"
        Me.cmb_port2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmb_port2.Size = New System.Drawing.Size(68, 20)
        Me.cmb_port2.TabIndex = 4
        '
        'cmb_baudrate2
        '
        Me.cmb_baudrate2.FormattingEnabled = True
        Me.cmb_baudrate2.Items.AddRange(New Object() {"9600", "19200", "38400", "57600", "115200"})
        Me.cmb_baudrate2.Location = New System.Drawing.Point(186, 117)
        Me.cmb_baudrate2.Name = "cmb_baudrate2"
        Me.cmb_baudrate2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmb_baudrate2.Size = New System.Drawing.Size(68, 20)
        Me.cmb_baudrate2.TabIndex = 4
        '
        'cmb_stopbits2
        '
        Me.cmb_stopbits2.FormattingEnabled = True
        Me.cmb_stopbits2.Items.AddRange(New Object() {"1", "2"})
        Me.cmb_stopbits2.Location = New System.Drawing.Point(329, 117)
        Me.cmb_stopbits2.Name = "cmb_stopbits2"
        Me.cmb_stopbits2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmb_stopbits2.Size = New System.Drawing.Size(68, 20)
        Me.cmb_stopbits2.TabIndex = 4
        '
        'cmb_parity2
        '
        Me.cmb_parity2.FormattingEnabled = True
        Me.cmb_parity2.Items.AddRange(New Object() {"None", "Odd", "Even"})
        Me.cmb_parity2.Location = New System.Drawing.Point(401, 117)
        Me.cmb_parity2.Name = "cmb_parity2"
        Me.cmb_parity2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmb_parity2.Size = New System.Drawing.Size(68, 20)
        Me.cmb_parity2.TabIndex = 4
        '
        'btn_comset1
        '
        Me.btn_comset1.Location = New System.Drawing.Point(100, 129)
        Me.btn_comset1.Name = "btn_comset1"
        Me.btn_comset1.Size = New System.Drawing.Size(65, 30)
        Me.btn_comset1.TabIndex = 5
        Me.btn_comset1.Text = "設定"
        Me.btn_comset1.UseVisualStyleBackColor = True
        '
        'btn_comset2
        '
        Me.btn_comset2.Location = New System.Drawing.Point(100, 180)
        Me.btn_comset2.Name = "btn_comset2"
        Me.btn_comset2.Size = New System.Drawing.Size(65, 30)
        Me.btn_comset2.TabIndex = 5
        Me.btn_comset2.Text = "設定"
        Me.btn_comset2.UseVisualStyleBackColor = True
        '
        'btn_online1
        '
        Me.btn_online1.Location = New System.Drawing.Point(170, 129)
        Me.btn_online1.Name = "btn_online1"
        Me.btn_online1.Size = New System.Drawing.Size(65, 30)
        Me.btn_online1.TabIndex = 5
        Me.btn_online1.Text = "オフライン"
        Me.btn_online1.UseVisualStyleBackColor = True
        '
        'btn_online2
        '
        Me.btn_online2.Location = New System.Drawing.Point(170, 180)
        Me.btn_online2.Name = "btn_online2"
        Me.btn_online2.Size = New System.Drawing.Size(65, 30)
        Me.btn_online2.TabIndex = 5
        Me.btn_online2.Text = "オフライン"
        Me.btn_online2.UseVisualStyleBackColor = True
        '
        'bnt_test
        '
        Me.bnt_test.Location = New System.Drawing.Point(239, 181)
        Me.bnt_test.Name = "bnt_test"
        Me.bnt_test.Size = New System.Drawing.Size(65, 29)
        Me.bnt_test.TabIndex = 5
        Me.bnt_test.Text = "テスト"
        Me.bnt_test.UseVisualStyleBackColor = True
        '
        'btn_monitor
        '
        Me.btn_monitor.Location = New System.Drawing.Point(239, 130)
        Me.btn_monitor.Name = "btn_monitor"
        Me.btn_monitor.Size = New System.Drawing.Size(65, 29)
        Me.btn_monitor.TabIndex = 5
        Me.btn_monitor.Text = "モニター"
        Me.btn_monitor.UseVisualStyleBackColor = True
        '
        'lbl_manutest
        '
        Me.lbl_manutest.AutoSize = True
        Me.lbl_manutest.Location = New System.Drawing.Point(256, 213)
        Me.lbl_manutest.Name = "lbl_manutest"
        Me.lbl_manutest.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lbl_manutest.Size = New System.Drawing.Size(37, 15)
        Me.lbl_manutest.TabIndex = 6
        Me.lbl_manutest.Text = "result"
        '
        'lbl_plcpc
        '
        Me.lbl_plcpc.AutoSize = True
        Me.lbl_plcpc.Location = New System.Drawing.Point(349, 97)
        Me.lbl_plcpc.Name = "lbl_plcpc"
        Me.lbl_plcpc.Size = New System.Drawing.Size(62, 15)
        Me.lbl_plcpc.TabIndex = 6
        Me.lbl_plcpc.Text = "PLC ⇒ PC"
        '
        'lbl_pcplc
        '
        Me.lbl_pcplc.AutoSize = True
        Me.lbl_pcplc.Location = New System.Drawing.Point(421, 98)
        Me.lbl_pcplc.Name = "lbl_pcplc"
        Me.lbl_pcplc.Size = New System.Drawing.Size(62, 15)
        Me.lbl_pcplc.TabIndex = 6
        Me.lbl_pcplc.Text = "PC ⇒ PLC"
        '
        'lst_read
        '
        Me.lst_read.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lst_read.FormattingEnabled = True
        Me.lst_read.Location = New System.Drawing.Point(349, 132)
        Me.lst_read.Name = "lst_read"
        Me.lst_read.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lst_read.Size = New System.Drawing.Size(59, 134)
        Me.lst_read.TabIndex = 7
        '
        'lst_write
        '
        Me.lst_write.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lst_write.FormattingEnabled = True
        Me.lst_write.Location = New System.Drawing.Point(421, 132)
        Me.lst_write.Name = "lst_write"
        Me.lst_write.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lst_write.Size = New System.Drawing.Size(59, 134)
        Me.lst_write.TabIndex = 7
        '
        'Timer1
        '
        '
        'lbl_readtop
        '
        Me.lbl_readtop.AutoSize = True
        Me.lbl_readtop.Location = New System.Drawing.Point(359, 113)
        Me.lbl_readtop.Name = "lbl_readtop"
        Me.lbl_readtop.Size = New System.Drawing.Size(44, 15)
        Me.lbl_readtop.TabIndex = 6
        Me.lbl_readtop.Text = "DT500"
        '
        'lbl_writetop
        '
        Me.lbl_writetop.AutoSize = True
        Me.lbl_writetop.Location = New System.Drawing.Point(430, 114)
        Me.lbl_writetop.Name = "lbl_writetop"
        Me.lbl_writetop.Size = New System.Drawing.Size(44, 15)
        Me.lbl_writetop.TabIndex = 6
        Me.lbl_writetop.Text = "DT510"
        '
        'lbl_databits
        '
        Me.lbl_databits.AutoSize = True
        Me.lbl_databits.Location = New System.Drawing.Point(264, 76)
        Me.lbl_databits.Name = "lbl_databits"
        Me.lbl_databits.Size = New System.Drawing.Size(56, 12)
        Me.lbl_databits.TabIndex = 2
        Me.lbl_databits.Text = "データビット"
        '
        'cmb_databits1
        '
        Me.cmb_databits1.FormattingEnabled = True
        Me.cmb_databits1.Items.AddRange(New Object() {"7", "8"})
        Me.cmb_databits1.Location = New System.Drawing.Point(258, 91)
        Me.cmb_databits1.Name = "cmb_databits1"
        Me.cmb_databits1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmb_databits1.Size = New System.Drawing.Size(68, 20)
        Me.cmb_databits1.TabIndex = 4
        '
        'cmb_databits2
        '
        Me.cmb_databits2.FormattingEnabled = True
        Me.cmb_databits2.Items.AddRange(New Object() {"7", "8"})
        Me.cmb_databits2.Location = New System.Drawing.Point(258, 117)
        Me.cmb_databits2.Name = "cmb_databits2"
        Me.cmb_databits2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmb_databits2.Size = New System.Drawing.Size(68, 20)
        Me.cmb_databits2.TabIndex = 4
        '
        'Timer2
        '
        '
        'btn_start_batch
        '
        Me.btn_start_batch.BackColor = System.Drawing.Color.MediumSpringGreen
        Me.btn_start_batch.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btn_start_batch.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_start_batch.ForeColor = System.Drawing.Color.Black
        Me.btn_start_batch.Location = New System.Drawing.Point(362, 20)
        Me.btn_start_batch.Name = "btn_start_batch"
        Me.btn_start_batch.Size = New System.Drawing.Size(133, 63)
        Me.btn_start_batch.TabIndex = 8
        Me.btn_start_batch.Text = "START MEASURE"
        Me.btn_start_batch.UseVisualStyleBackColor = False
        '
        'btn_close
        '
        Me.btn_close.BackColor = System.Drawing.Color.Tomato
        Me.btn_close.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_close.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_close.Location = New System.Drawing.Point(1065, 538)
        Me.btn_close.Name = "btn_close"
        Me.btn_close.Size = New System.Drawing.Size(111, 41)
        Me.btn_close.TabIndex = 8
        Me.btn_close.Text = "CLOSE"
        Me.btn_close.UseVisualStyleBackColor = False
        '
        'Timer3
        '
        Me.Timer3.Interval = 250
        '
        'lst_result
        '
        Me.lst_result.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lst_result.FormattingEnabled = True
        Me.lst_result.ItemHeight = 29
        Me.lst_result.Location = New System.Drawing.Point(66, 131)
        Me.lst_result.Name = "lst_result"
        Me.lst_result.Size = New System.Drawing.Size(108, 91)
        Me.lst_result.TabIndex = 12
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(400, 86)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(45, 15)
        Me.Label3.TabIndex = 13
        Me.Label3.Text = "Label3"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(18, 104)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(40, 24)
        Me.Label4.TabIndex = 14
        Me.Label4.Text = "PIN"
        '
        'lst_maxmin
        '
        Me.lst_maxmin.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lst_maxmin.FormattingEnabled = True
        Me.lst_maxmin.ItemHeight = 29
        Me.lst_maxmin.Location = New System.Drawing.Point(395, 131)
        Me.lst_maxmin.Name = "lst_maxmin"
        Me.lst_maxmin.Size = New System.Drawing.Size(100, 91)
        Me.lst_maxmin.TabIndex = 12
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(329, 131)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(65, 29)
        Me.Label7.TabIndex = 14
        Me.Label7.Text = "MAX"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(329, 160)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(57, 29)
        Me.Label8.TabIndex = 14
        Me.Label8.Text = "MIN"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(329, 189)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(59, 29)
        Me.Label9.TabIndex = 14
        Me.Label9.Text = "AVE"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(18, 31)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(76, 20)
        Me.Label10.TabIndex = 15
        Me.Label10.Text = "UP LIMIT"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(17, 64)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(90, 20)
        Me.Label11.TabIndex = 15
        Me.Label11.Text = "LOW LIMIT"
        '
        'txt_uplimit
        '
        Me.txt_uplimit.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_uplimit.Location = New System.Drawing.Point(120, 25)
        Me.txt_uplimit.Name = "txt_uplimit"
        Me.txt_uplimit.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txt_uplimit.Size = New System.Drawing.Size(91, 26)
        Me.txt_uplimit.TabIndex = 16
        Me.txt_uplimit.Text = "7.50"
        Me.txt_uplimit.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txt_lowlimit
        '
        Me.txt_lowlimit.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_lowlimit.Location = New System.Drawing.Point(120, 60)
        Me.txt_lowlimit.Name = "txt_lowlimit"
        Me.txt_lowlimit.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txt_lowlimit.Size = New System.Drawing.Size(91, 26)
        Me.txt_lowlimit.TabIndex = 16
        Me.txt_lowlimit.Text = "6.00"
        Me.txt_lowlimit.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'timer_dt4
        '
        '
        'lst_judge
        '
        Me.lst_judge.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lst_judge.FormattingEnabled = True
        Me.lst_judge.ItemHeight = 29
        Me.lst_judge.Location = New System.Drawing.Point(180, 131)
        Me.lst_judge.Name = "lst_judge"
        Me.lst_judge.Size = New System.Drawing.Size(54, 91)
        Me.lst_judge.TabIndex = 12
        '
        'lst_No
        '
        Me.lst_No.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lst_No.FormattingEnabled = True
        Me.lst_No.ItemHeight = 29
        Me.lst_No.Location = New System.Drawing.Point(18, 131)
        Me.lst_No.Name = "lst_No"
        Me.lst_No.Size = New System.Drawing.Size(39, 91)
        Me.lst_No.TabIndex = 12
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.btn_comset1)
        Me.GroupBox1.Controls.Add(Me.btn_online1)
        Me.GroupBox1.Controls.Add(Me.btn_monitor)
        Me.GroupBox1.Controls.Add(Me.Label12)
        Me.GroupBox1.Controls.Add(Me.btn_comset2)
        Me.GroupBox1.Controls.Add(Me.bnt_test)
        Me.GroupBox1.Controls.Add(Me.btn_online2)
        Me.GroupBox1.Controls.Add(Me.Label13)
        Me.GroupBox1.Controls.Add(Me.lbl_manutest)
        Me.GroupBox1.Controls.Add(Me.lst_read)
        Me.GroupBox1.Controls.Add(Me.lbl_plcpc)
        Me.GroupBox1.Controls.Add(Me.lbl_readtop)
        Me.GroupBox1.Controls.Add(Me.lbl_writetop)
        Me.GroupBox1.Controls.Add(Me.lst_write)
        Me.GroupBox1.Controls.Add(Me.lbl_pcplc)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(15, 54)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(509, 279)
        Me.GroupBox1.TabIndex = 17
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Connection"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(27, 134)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(54, 15)
        Me.Label12.TabIndex = 3
        Me.Label12.Text = "PLCリンク"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(27, 185)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(63, 15)
        Me.Label13.TabIndex = 2
        Me.Label13.Text = "パネルメータ"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.lbl_cycletime)
        Me.GroupBox2.Controls.Add(Me.Label23)
        Me.GroupBox2.Controls.Add(Me.lst_rank)
        Me.GroupBox2.Controls.Add(Me.btn_start_batch)
        Me.GroupBox2.Controls.Add(Me.Label9)
        Me.GroupBox2.Controls.Add(Me.txt_lowlimit)
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.Controls.Add(Me.Label10)
        Me.GroupBox2.Controls.Add(Me.txt_uplimit)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Controls.Add(Me.Label11)
        Me.GroupBox2.Controls.Add(Me.Label3)
        Me.GroupBox2.Controls.Add(Me.lst_judge)
        Me.GroupBox2.Controls.Add(Me.Rank)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Controls.Add(Me.lst_result)
        Me.GroupBox2.Controls.Add(Me.lst_maxmin)
        Me.GroupBox2.Controls.Add(Me.lst_No)
        Me.GroupBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.Location = New System.Drawing.Point(15, 345)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(509, 236)
        Me.GroupBox2.TabIndex = 18
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Batch Measurement"
        '
        'lbl_cycletime
        '
        Me.lbl_cycletime.BackColor = System.Drawing.Color.LightYellow
        Me.lbl_cycletime.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_cycletime.Location = New System.Drawing.Point(242, 42)
        Me.lbl_cycletime.Name = "lbl_cycletime"
        Me.lbl_cycletime.Size = New System.Drawing.Size(69, 41)
        Me.lbl_cycletime.TabIndex = 19
        Me.lbl_cycletime.Text = "xx"
        Me.lbl_cycletime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(239, 18)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(73, 15)
        Me.Label23.TabIndex = 18
        Me.Label23.Text = "Cycle Time :"
        '
        'lst_rank
        '
        Me.lst_rank.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lst_rank.FormattingEnabled = True
        Me.lst_rank.ItemHeight = 29
        Me.lst_rank.Location = New System.Drawing.Point(243, 132)
        Me.lst_rank.Name = "lst_rank"
        Me.lst_rank.Size = New System.Drawing.Size(47, 91)
        Me.lst_rank.TabIndex = 17
        '
        'Rank
        '
        Me.Rank.AutoSize = True
        Me.Rank.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Rank.Location = New System.Drawing.Point(242, 104)
        Me.Rank.Name = "Rank"
        Me.Rank.Size = New System.Drawing.Size(53, 24)
        Me.Rank.TabIndex = 14
        Me.Rank.Text = "Rank"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(172, 104)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(63, 24)
        Me.Label6.TabIndex = 14
        Me.Label6.Text = "Judge"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(84, 104)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(62, 24)
        Me.Label5.TabIndex = 14
        Me.Label5.Text = "Result"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.lbl_zpos)
        Me.GroupBox3.Controls.Add(Me.lbl_ypos)
        Me.GroupBox3.Controls.Add(Me.lbl_xpos)
        Me.GroupBox3.Controls.Add(Me.lbl_automaualvb)
        Me.GroupBox3.Controls.Add(Me.lbl_control)
        Me.GroupBox3.Controls.Add(Me.btn_z0)
        Me.GroupBox3.Controls.Add(Me.btn_z5)
        Me.GroupBox3.Controls.Add(Me.btn_z4)
        Me.GroupBox3.Controls.Add(Me.btn_z3)
        Me.GroupBox3.Controls.Add(Me.btn_z2)
        Me.GroupBox3.Controls.Add(Me.btn_z1)
        Me.GroupBox3.Controls.Add(Me.btn_y0)
        Me.GroupBox3.Controls.Add(Me.btn_y5)
        Me.GroupBox3.Controls.Add(Me.btn_y4)
        Me.GroupBox3.Controls.Add(Me.btn_y3)
        Me.GroupBox3.Controls.Add(Me.btn_y2)
        Me.GroupBox3.Controls.Add(Me.btn_y1)
        Me.GroupBox3.Controls.Add(Me.btn_x0)
        Me.GroupBox3.Controls.Add(Me.btn_x5)
        Me.GroupBox3.Controls.Add(Me.btn_x4)
        Me.GroupBox3.Controls.Add(Me.btn_x3)
        Me.GroupBox3.Controls.Add(Me.btn_x2)
        Me.GroupBox3.Controls.Add(Me.btn_x1)
        Me.GroupBox3.Controls.Add(Me.Label16)
        Me.GroupBox3.Controls.Add(Me.Label15)
        Me.GroupBox3.Controls.Add(Me.Label14)
        Me.GroupBox3.Controls.Add(Me.btn_manual)
        Me.GroupBox3.Controls.Add(Me.btn_auto)
        Me.GroupBox3.Controls.Add(Me.chuck_open)
        Me.GroupBox3.Controls.Add(Me.btn_stop_robot)
        Me.GroupBox3.Controls.Add(Me.btn_start_robot)
        Me.GroupBox3.Controls.Add(Me.btn_origin)
        Me.GroupBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.Location = New System.Drawing.Point(530, 54)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(178, 527)
        Me.GroupBox3.TabIndex = 19
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Robot Operation"
        '
        'lbl_zpos
        '
        Me.lbl_zpos.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.lbl_zpos.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_zpos.Location = New System.Drawing.Point(107, 428)
        Me.lbl_zpos.Name = "lbl_zpos"
        Me.lbl_zpos.Size = New System.Drawing.Size(27, 23)
        Me.lbl_zpos.TabIndex = 27
        Me.lbl_zpos.Text = "Z"
        Me.lbl_zpos.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lbl_ypos
        '
        Me.lbl_ypos.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.lbl_ypos.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_ypos.Location = New System.Drawing.Point(107, 316)
        Me.lbl_ypos.Name = "lbl_ypos"
        Me.lbl_ypos.Size = New System.Drawing.Size(27, 23)
        Me.lbl_ypos.TabIndex = 27
        Me.lbl_ypos.Text = "Y"
        Me.lbl_ypos.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lbl_xpos
        '
        Me.lbl_xpos.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.lbl_xpos.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_xpos.Location = New System.Drawing.Point(107, 209)
        Me.lbl_xpos.Name = "lbl_xpos"
        Me.lbl_xpos.Size = New System.Drawing.Size(27, 23)
        Me.lbl_xpos.TabIndex = 27
        Me.lbl_xpos.Text = "X"
        Me.lbl_xpos.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lbl_automaualvb
        '
        Me.lbl_automaualvb.AutoSize = True
        Me.lbl_automaualvb.Location = New System.Drawing.Point(7, 53)
        Me.lbl_automaualvb.Name = "lbl_automaualvb"
        Me.lbl_automaualvb.Size = New System.Drawing.Size(52, 15)
        Me.lbl_automaualvb.TabIndex = 26
        Me.lbl_automaualvb.Text = "Label25"
        '
        'lbl_control
        '
        Me.lbl_control.AutoSize = True
        Me.lbl_control.Location = New System.Drawing.Point(6, 27)
        Me.lbl_control.Name = "lbl_control"
        Me.lbl_control.Size = New System.Drawing.Size(52, 15)
        Me.lbl_control.TabIndex = 25
        Me.lbl_control.Text = "Label24"
        '
        'btn_z0
        '
        Me.btn_z0.Location = New System.Drawing.Point(111, 488)
        Me.btn_z0.Name = "btn_z0"
        Me.btn_z0.Size = New System.Drawing.Size(35, 23)
        Me.btn_z0.TabIndex = 24
        Me.btn_z0.Text = "0"
        Me.btn_z0.UseVisualStyleBackColor = True
        '
        'btn_z5
        '
        Me.btn_z5.Location = New System.Drawing.Point(68, 488)
        Me.btn_z5.Name = "btn_z5"
        Me.btn_z5.Size = New System.Drawing.Size(36, 23)
        Me.btn_z5.TabIndex = 23
        Me.btn_z5.Text = "5"
        Me.btn_z5.UseVisualStyleBackColor = True
        '
        'btn_z4
        '
        Me.btn_z4.Location = New System.Drawing.Point(26, 488)
        Me.btn_z4.Name = "btn_z4"
        Me.btn_z4.Size = New System.Drawing.Size(36, 23)
        Me.btn_z4.TabIndex = 22
        Me.btn_z4.Text = "4"
        Me.btn_z4.UseVisualStyleBackColor = True
        '
        'btn_z3
        '
        Me.btn_z3.Location = New System.Drawing.Point(111, 459)
        Me.btn_z3.Name = "btn_z3"
        Me.btn_z3.Size = New System.Drawing.Size(35, 23)
        Me.btn_z3.TabIndex = 21
        Me.btn_z3.Text = "3"
        Me.btn_z3.UseVisualStyleBackColor = True
        '
        'btn_z2
        '
        Me.btn_z2.Location = New System.Drawing.Point(68, 459)
        Me.btn_z2.Name = "btn_z2"
        Me.btn_z2.Size = New System.Drawing.Size(36, 23)
        Me.btn_z2.TabIndex = 20
        Me.btn_z2.Text = "2"
        Me.btn_z2.UseVisualStyleBackColor = True
        '
        'btn_z1
        '
        Me.btn_z1.Location = New System.Drawing.Point(26, 459)
        Me.btn_z1.Name = "btn_z1"
        Me.btn_z1.Size = New System.Drawing.Size(36, 23)
        Me.btn_z1.TabIndex = 19
        Me.btn_z1.Text = "1"
        Me.btn_z1.UseVisualStyleBackColor = True
        '
        'btn_y0
        '
        Me.btn_y0.Location = New System.Drawing.Point(111, 377)
        Me.btn_y0.Name = "btn_y0"
        Me.btn_y0.Size = New System.Drawing.Size(35, 23)
        Me.btn_y0.TabIndex = 18
        Me.btn_y0.Text = "0"
        Me.btn_y0.UseVisualStyleBackColor = True
        '
        'btn_y5
        '
        Me.btn_y5.Location = New System.Drawing.Point(68, 377)
        Me.btn_y5.Name = "btn_y5"
        Me.btn_y5.Size = New System.Drawing.Size(36, 23)
        Me.btn_y5.TabIndex = 17
        Me.btn_y5.Text = "5"
        Me.btn_y5.UseVisualStyleBackColor = True
        '
        'btn_y4
        '
        Me.btn_y4.Location = New System.Drawing.Point(26, 377)
        Me.btn_y4.Name = "btn_y4"
        Me.btn_y4.Size = New System.Drawing.Size(36, 23)
        Me.btn_y4.TabIndex = 16
        Me.btn_y4.Text = "4"
        Me.btn_y4.UseVisualStyleBackColor = True
        '
        'btn_y3
        '
        Me.btn_y3.Location = New System.Drawing.Point(111, 345)
        Me.btn_y3.Name = "btn_y3"
        Me.btn_y3.Size = New System.Drawing.Size(35, 23)
        Me.btn_y3.TabIndex = 15
        Me.btn_y3.Text = "3"
        Me.btn_y3.UseVisualStyleBackColor = True
        '
        'btn_y2
        '
        Me.btn_y2.Location = New System.Drawing.Point(68, 345)
        Me.btn_y2.Name = "btn_y2"
        Me.btn_y2.Size = New System.Drawing.Size(36, 23)
        Me.btn_y2.TabIndex = 14
        Me.btn_y2.Text = "2"
        Me.btn_y2.UseVisualStyleBackColor = True
        '
        'btn_y1
        '
        Me.btn_y1.Location = New System.Drawing.Point(26, 345)
        Me.btn_y1.Name = "btn_y1"
        Me.btn_y1.Size = New System.Drawing.Size(36, 23)
        Me.btn_y1.TabIndex = 13
        Me.btn_y1.Text = "1"
        Me.btn_y1.UseVisualStyleBackColor = True
        '
        'btn_x0
        '
        Me.btn_x0.Location = New System.Drawing.Point(111, 270)
        Me.btn_x0.Name = "btn_x0"
        Me.btn_x0.Size = New System.Drawing.Size(35, 23)
        Me.btn_x0.TabIndex = 12
        Me.btn_x0.Text = "0"
        Me.btn_x0.UseVisualStyleBackColor = True
        '
        'btn_x5
        '
        Me.btn_x5.Location = New System.Drawing.Point(68, 270)
        Me.btn_x5.Name = "btn_x5"
        Me.btn_x5.Size = New System.Drawing.Size(36, 23)
        Me.btn_x5.TabIndex = 11
        Me.btn_x5.Text = "5"
        Me.btn_x5.UseVisualStyleBackColor = True
        '
        'btn_x4
        '
        Me.btn_x4.Location = New System.Drawing.Point(26, 270)
        Me.btn_x4.Name = "btn_x4"
        Me.btn_x4.Size = New System.Drawing.Size(36, 23)
        Me.btn_x4.TabIndex = 10
        Me.btn_x4.Text = "4"
        Me.btn_x4.UseVisualStyleBackColor = True
        '
        'btn_x3
        '
        Me.btn_x3.Location = New System.Drawing.Point(110, 240)
        Me.btn_x3.Name = "btn_x3"
        Me.btn_x3.Size = New System.Drawing.Size(36, 23)
        Me.btn_x3.TabIndex = 9
        Me.btn_x3.Text = "3"
        Me.btn_x3.UseVisualStyleBackColor = True
        '
        'btn_x2
        '
        Me.btn_x2.Location = New System.Drawing.Point(68, 240)
        Me.btn_x2.Name = "btn_x2"
        Me.btn_x2.Size = New System.Drawing.Size(36, 23)
        Me.btn_x2.TabIndex = 8
        Me.btn_x2.Text = "2"
        Me.btn_x2.UseVisualStyleBackColor = True
        '
        'btn_x1
        '
        Me.btn_x1.Location = New System.Drawing.Point(26, 240)
        Me.btn_x1.Name = "btn_x1"
        Me.btn_x1.Size = New System.Drawing.Size(36, 23)
        Me.btn_x1.TabIndex = 7
        Me.btn_x1.Text = "1"
        Me.btn_x1.UseVisualStyleBackColor = True
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(6, 428)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(74, 15)
        Me.Label16.TabIndex = 6
        Me.Label16.Text = "Z-POSITION"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(6, 318)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(74, 15)
        Me.Label15.TabIndex = 6
        Me.Label15.Text = "Y-POSITION"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(7, 212)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(75, 15)
        Me.Label14.TabIndex = 6
        Me.Label14.Text = "X-POSITION"
        '
        'btn_manual
        '
        Me.btn_manual.Location = New System.Drawing.Point(89, 123)
        Me.btn_manual.Name = "btn_manual"
        Me.btn_manual.Size = New System.Drawing.Size(73, 31)
        Me.btn_manual.TabIndex = 5
        Me.btn_manual.Text = "MANUAL"
        Me.btn_manual.UseVisualStyleBackColor = True
        '
        'btn_auto
        '
        Me.btn_auto.Location = New System.Drawing.Point(7, 123)
        Me.btn_auto.Name = "btn_auto"
        Me.btn_auto.Size = New System.Drawing.Size(75, 31)
        Me.btn_auto.TabIndex = 4
        Me.btn_auto.Text = "AUTO"
        Me.btn_auto.UseVisualStyleBackColor = True
        '
        'chuck_open
        '
        Me.chuck_open.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chuck_open.Location = New System.Drawing.Point(87, 87)
        Me.chuck_open.Name = "chuck_open"
        Me.chuck_open.Size = New System.Drawing.Size(75, 31)
        Me.chuck_open.TabIndex = 3
        Me.chuck_open.Text = "Chuck Open"
        Me.chuck_open.UseVisualStyleBackColor = True
        '
        'btn_stop_robot
        '
        Me.btn_stop_robot.Location = New System.Drawing.Point(87, 160)
        Me.btn_stop_robot.Name = "btn_stop_robot"
        Me.btn_stop_robot.Size = New System.Drawing.Size(75, 31)
        Me.btn_stop_robot.TabIndex = 2
        Me.btn_stop_robot.Text = "STOP"
        Me.btn_stop_robot.UseVisualStyleBackColor = True
        '
        'btn_start_robot
        '
        Me.btn_start_robot.BackColor = System.Drawing.Color.Gainsboro
        Me.btn_start_robot.Location = New System.Drawing.Point(6, 160)
        Me.btn_start_robot.Name = "btn_start_robot"
        Me.btn_start_robot.Size = New System.Drawing.Size(75, 31)
        Me.btn_start_robot.TabIndex = 1
        Me.btn_start_robot.Text = "START"
        Me.btn_start_robot.UseVisualStyleBackColor = False
        '
        'btn_origin
        '
        Me.btn_origin.BackColor = System.Drawing.Color.Gainsboro
        Me.btn_origin.Location = New System.Drawing.Point(6, 87)
        Me.btn_origin.Name = "btn_origin"
        Me.btn_origin.Size = New System.Drawing.Size(75, 31)
        Me.btn_origin.TabIndex = 0
        Me.btn_origin.Text = "ORIGIN"
        Me.btn_origin.UseVisualStyleBackColor = False
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.list_judgement)
        Me.GroupBox4.Controls.Add(Me.list_lowlimit)
        Me.GroupBox4.Controls.Add(Me.list_uplimit)
        Me.GroupBox4.Controls.Add(Me.list_result)
        Me.GroupBox4.Controls.Add(Me.list_datetime)
        Me.GroupBox4.Controls.Add(Me.list_no)
        Me.GroupBox4.Controls.Add(Me.Label22)
        Me.GroupBox4.Controls.Add(Me.Label21)
        Me.GroupBox4.Controls.Add(Me.Label20)
        Me.GroupBox4.Controls.Add(Me.Label19)
        Me.GroupBox4.Controls.Add(Me.Label18)
        Me.GroupBox4.Controls.Add(Me.Label17)
        Me.GroupBox4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox4.Location = New System.Drawing.Point(714, 54)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(471, 480)
        Me.GroupBox4.TabIndex = 20
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Continous Measurement"
        '
        'list_judgement
        '
        Me.list_judgement.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.list_judgement.FormattingEnabled = True
        Me.list_judgement.ItemHeight = 16
        Me.list_judgement.Location = New System.Drawing.Point(390, 43)
        Me.list_judgement.Name = "list_judgement"
        Me.list_judgement.Size = New System.Drawing.Size(72, 420)
        Me.list_judgement.TabIndex = 1
        '
        'list_lowlimit
        '
        Me.list_lowlimit.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.list_lowlimit.FormatString = "N2"
        Me.list_lowlimit.FormattingEnabled = True
        Me.list_lowlimit.ItemHeight = 16
        Me.list_lowlimit.Location = New System.Drawing.Point(338, 43)
        Me.list_lowlimit.Name = "list_lowlimit"
        Me.list_lowlimit.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.list_lowlimit.Size = New System.Drawing.Size(49, 420)
        Me.list_lowlimit.TabIndex = 1
        '
        'list_uplimit
        '
        Me.list_uplimit.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.list_uplimit.FormatString = "N2"
        Me.list_uplimit.FormattingEnabled = True
        Me.list_uplimit.ItemHeight = 16
        Me.list_uplimit.Location = New System.Drawing.Point(286, 43)
        Me.list_uplimit.Name = "list_uplimit"
        Me.list_uplimit.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.list_uplimit.Size = New System.Drawing.Size(49, 420)
        Me.list_uplimit.TabIndex = 1
        '
        'list_result
        '
        Me.list_result.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.list_result.FormatString = "N2"
        Me.list_result.FormattingEnabled = True
        Me.list_result.ItemHeight = 16
        Me.list_result.Location = New System.Drawing.Point(202, 43)
        Me.list_result.Name = "list_result"
        Me.list_result.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.list_result.Size = New System.Drawing.Size(81, 420)
        Me.list_result.TabIndex = 1
        '
        'list_datetime
        '
        Me.list_datetime.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.list_datetime.FormatString = "G"
        Me.list_datetime.FormattingEnabled = True
        Me.list_datetime.ItemHeight = 16
        Me.list_datetime.Location = New System.Drawing.Point(48, 43)
        Me.list_datetime.Name = "list_datetime"
        Me.list_datetime.Size = New System.Drawing.Size(151, 420)
        Me.list_datetime.TabIndex = 1
        '
        'list_no
        '
        Me.list_no.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.list_no.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.list_no.FormattingEnabled = True
        Me.list_no.ItemHeight = 16
        Me.list_no.Location = New System.Drawing.Point(6, 43)
        Me.list_no.Name = "list_no"
        Me.list_no.Size = New System.Drawing.Size(39, 420)
        Me.list_no.TabIndex = 1
        '
        'Label22
        '
        Me.Label22.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label22.Location = New System.Drawing.Point(390, 19)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(72, 21)
        Me.Label22.TabIndex = 0
        Me.Label22.Text = "Judgement"
        Me.Label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label21
        '
        Me.Label21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label21.Location = New System.Drawing.Point(338, 19)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(49, 21)
        Me.Label21.TabIndex = 0
        Me.Label21.Text = "Low"
        Me.Label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label20
        '
        Me.Label20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label20.Location = New System.Drawing.Point(286, 19)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(49, 21)
        Me.Label20.TabIndex = 0
        Me.Label20.Text = "Up"
        Me.Label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label19
        '
        Me.Label19.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label19.Location = New System.Drawing.Point(202, 19)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(81, 21)
        Me.Label19.TabIndex = 0
        Me.Label19.Text = "Result"
        Me.Label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label18
        '
        Me.Label18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label18.Location = New System.Drawing.Point(48, 19)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(151, 21)
        Me.Label18.TabIndex = 0
        Me.Label18.Text = "Date and Time"
        Me.Label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label17
        '
        Me.Label17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label17.Location = New System.Drawing.Point(6, 19)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(39, 21)
        Me.Label17.TabIndex = 0
        Me.Label17.Text = "No"
        Me.Label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'timer_dt1
        '
        '
        'timer_dt2
        '
        '
        'btn_save
        '
        Me.btn_save.BackColor = System.Drawing.Color.LimeGreen
        Me.btn_save.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btn_save.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_save.Location = New System.Drawing.Point(725, 538)
        Me.btn_save.Name = "btn_save"
        Me.btn_save.Size = New System.Drawing.Size(85, 41)
        Me.btn_save.TabIndex = 21
        Me.btn_save.Text = "Save CSV"
        Me.btn_save.UseVisualStyleBackColor = False
        '
        'btn_cleardata
        '
        Me.btn_cleardata.BackColor = System.Drawing.Color.Gainsboro
        Me.btn_cleardata.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btn_cleardata.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_cleardata.ForeColor = System.Drawing.Color.Red
        Me.btn_cleardata.Location = New System.Drawing.Point(816, 538)
        Me.btn_cleardata.Name = "btn_cleardata"
        Me.btn_cleardata.Size = New System.Drawing.Size(79, 41)
        Me.btn_cleardata.TabIndex = 22
        Me.btn_cleardata.Text = "Clear Data"
        Me.btn_cleardata.UseVisualStyleBackColor = False
        '
        'testbutton
        '
        Me.testbutton.Location = New System.Drawing.Point(993, 18)
        Me.testbutton.Name = "testbutton"
        Me.testbutton.Size = New System.Drawing.Size(75, 23)
        Me.testbutton.TabIndex = 24
        Me.testbutton.Text = "TEST CSV"
        Me.testbutton.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1200, 593)
        Me.Controls.Add(Me.testbutton)
        Me.Controls.Add(Me.btn_cleardata)
        Me.Controls.Add(Me.btn_close)
        Me.Controls.Add(Me.btn_save)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.cmb_parity2)
        Me.Controls.Add(Me.cmb_parity1)
        Me.Controls.Add(Me.cmb_databits2)
        Me.Controls.Add(Me.cmb_stopbits2)
        Me.Controls.Add(Me.cmb_databits1)
        Me.Controls.Add(Me.cmb_stopbits1)
        Me.Controls.Add(Me.cmb_baudrate2)
        Me.Controls.Add(Me.cmb_baudrate1)
        Me.Controls.Add(Me.cmb_port2)
        Me.Controls.Add(Me.cmb_port1)
        Me.Controls.Add(Me.lbl_comset2)
        Me.Controls.Add(Me.lbl_databits)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lbl_baudrate)
        Me.Controls.Add(Me.lbl_port)
        Me.Controls.Add(Me.lbl_comset1)
        Me.Controls.Add(Me.lbl_title)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox3)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form1"
        Me.Text = "メカトローヘリ"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lbl_title As Label
    Friend WithEvents lbl_comset1 As Label
    Friend WithEvents lbl_comset2 As Label
    Friend WithEvents lbl_port As Label
    Friend WithEvents lbl_baudrate As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents cmb_port1 As ComboBox
    Friend WithEvents cmb_baudrate1 As ComboBox
    Friend WithEvents cmb_stopbits1 As ComboBox
    Friend WithEvents cmb_parity1 As ComboBox
    Friend WithEvents cmb_port2 As ComboBox
    Friend WithEvents cmb_baudrate2 As ComboBox
    Friend WithEvents cmb_stopbits2 As ComboBox
    Friend WithEvents cmb_parity2 As ComboBox
    Friend WithEvents btn_comset1 As Button
    Friend WithEvents btn_comset2 As Button
    Friend WithEvents btn_online1 As Button
    Friend WithEvents btn_online2 As Button
    Friend WithEvents bnt_test As Button
    Friend WithEvents btn_monitor As Button
    Friend WithEvents lbl_manutest As Label
    Friend WithEvents lbl_plcpc As Label
    Friend WithEvents lbl_pcplc As Label
    Friend WithEvents lst_read As ListBox
    Friend WithEvents lst_write As ListBox
    Friend WithEvents Timer1 As Timer
    Friend WithEvents SerialPort1 As IO.Ports.SerialPort
    Friend WithEvents SerialPort2 As IO.Ports.SerialPort
    Friend WithEvents lbl_readtop As Label
    Friend WithEvents lbl_writetop As Label
    Friend WithEvents lbl_databits As Label
    Friend WithEvents cmb_databits1 As ComboBox
    Friend WithEvents cmb_databits2 As ComboBox
    Friend WithEvents Timer2 As Timer
    Friend WithEvents btn_start_batch As Button
    Friend WithEvents btn_close As Button
    Friend WithEvents Timer3 As Timer
    Friend WithEvents lst_result As ListBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents lst_maxmin As ListBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents txt_uplimit As TextBox
    Friend WithEvents txt_lowlimit As TextBox
    Friend WithEvents timer_dt4 As Timer
    Friend WithEvents lst_judge As ListBox
    Friend WithEvents lst_No As ListBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents btn_origin As Button
    Friend WithEvents btn_start_robot As Button
    Friend WithEvents btn_stop_robot As Button
    Friend WithEvents chuck_open As Button
    Friend WithEvents Rank As Label
    Friend WithEvents timer_dt1 As Timer
    Friend WithEvents lst_rank As ListBox
    Friend WithEvents timer_dt2 As Timer
    Friend WithEvents btn_z0 As Button
    Friend WithEvents btn_z5 As Button
    Friend WithEvents btn_z4 As Button
    Friend WithEvents btn_z3 As Button
    Friend WithEvents btn_z2 As Button
    Friend WithEvents btn_z1 As Button
    Friend WithEvents btn_y0 As Button
    Friend WithEvents btn_y5 As Button
    Friend WithEvents btn_y4 As Button
    Friend WithEvents btn_y3 As Button
    Friend WithEvents btn_y2 As Button
    Friend WithEvents btn_y1 As Button
    Friend WithEvents btn_x0 As Button
    Friend WithEvents btn_x5 As Button
    Friend WithEvents btn_x4 As Button
    Friend WithEvents btn_x3 As Button
    Friend WithEvents btn_x2 As Button
    Friend WithEvents btn_x1 As Button
    Friend WithEvents Label16 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents btn_manual As Button
    Friend WithEvents btn_auto As Button
    Friend WithEvents list_judgement As ListBox
    Friend WithEvents list_lowlimit As ListBox
    Friend WithEvents list_uplimit As ListBox
    Friend WithEvents list_result As ListBox
    Friend WithEvents list_datetime As ListBox
    Friend WithEvents list_no As ListBox
    Friend WithEvents Label22 As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents btn_save As Button
    Friend WithEvents btn_cleardata As Button
    Friend WithEvents SaveFileCSV As SaveFileDialog
    Friend WithEvents testbutton As Button
    Friend WithEvents lbl_cycletime As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents lbl_automaualvb As Label
    Friend WithEvents lbl_control As Label
    Friend WithEvents lbl_zpos As Label
    Friend WithEvents lbl_ypos As Label
    Friend WithEvents lbl_xpos As Label
End Class
