﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lbl_title = New System.Windows.Forms.Label()
        Me.lbl_comset = New System.Windows.Forms.Label()
        Me.lbl_comset1 = New System.Windows.Forms.Label()
        Me.lbl_comset2 = New System.Windows.Forms.Label()
        Me.lbl_port = New System.Windows.Forms.Label()
        Me.lbl_baudrate = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.cmb_port1 = New System.Windows.Forms.ComboBox()
        Me.cmb_baudrate1 = New System.Windows.Forms.ComboBox()
        Me.cmb_stopbits1 = New System.Windows.Forms.ComboBox()
        Me.cmb_parity1 = New System.Windows.Forms.ComboBox()
        Me.cmb_port2 = New System.Windows.Forms.ComboBox()
        Me.cmb_baudrate2 = New System.Windows.Forms.ComboBox()
        Me.cmb_stopbits2 = New System.Windows.Forms.ComboBox()
        Me.cmb_parity2 = New System.Windows.Forms.ComboBox()
        Me.btn_comset1 = New System.Windows.Forms.Button()
        Me.btn_comset2 = New System.Windows.Forms.Button()
        Me.btn_online1 = New System.Windows.Forms.Button()
        Me.btn_online2 = New System.Windows.Forms.Button()
        Me.bnt_test = New System.Windows.Forms.Button()
        Me.btn_monitor = New System.Windows.Forms.Button()
        Me.lbl_manutest = New System.Windows.Forms.Label()
        Me.lbl_plcpc = New System.Windows.Forms.Label()
        Me.lbl_pcplc = New System.Windows.Forms.Label()
        Me.lst_read = New System.Windows.Forms.ListBox()
        Me.lst_write = New System.Windows.Forms.ListBox()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.SerialPort1 = New System.IO.Ports.SerialPort(Me.components)
        Me.SerialPort2 = New System.IO.Ports.SerialPort(Me.components)
        Me.lbl_readtop = New System.Windows.Forms.Label()
        Me.lbl_writetop = New System.Windows.Forms.Label()
        Me.lbl_databits = New System.Windows.Forms.Label()
        Me.cmb_databits1 = New System.Windows.Forms.ComboBox()
        Me.cmb_databits2 = New System.Windows.Forms.ComboBox()
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.SuspendLayout()
        '
        'lbl_title
        '
        Me.lbl_title.AutoSize = True
        Me.lbl_title.Font = New System.Drawing.Font("MS UI Gothic", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lbl_title.Location = New System.Drawing.Point(12, 9)
        Me.lbl_title.Name = "lbl_title"
        Me.lbl_title.Size = New System.Drawing.Size(492, 48)
        Me.lbl_title.TabIndex = 0
        Me.lbl_title.Text = "2020治工具応用メカトロ"
        '
        'lbl_comset
        '
        Me.lbl_comset.AutoSize = True
        Me.lbl_comset.Location = New System.Drawing.Point(27, 68)
        Me.lbl_comset.Name = "lbl_comset"
        Me.lbl_comset.Size = New System.Drawing.Size(53, 12)
        Me.lbl_comset.TabIndex = 1
        Me.lbl_comset.Text = "通信設定"
        '
        'lbl_comset1
        '
        Me.lbl_comset1.AutoSize = True
        Me.lbl_comset1.Location = New System.Drawing.Point(42, 121)
        Me.lbl_comset1.Name = "lbl_comset1"
        Me.lbl_comset1.Size = New System.Drawing.Size(61, 12)
        Me.lbl_comset1.TabIndex = 2
        Me.lbl_comset1.Text = "パネルメータ"
        '
        'lbl_comset2
        '
        Me.lbl_comset2.AutoSize = True
        Me.lbl_comset2.Location = New System.Drawing.Point(42, 96)
        Me.lbl_comset2.Name = "lbl_comset2"
        Me.lbl_comset2.Size = New System.Drawing.Size(50, 12)
        Me.lbl_comset2.TabIndex = 3
        Me.lbl_comset2.Text = "PLCリンク"
        '
        'lbl_port
        '
        Me.lbl_port.AutoSize = True
        Me.lbl_port.Location = New System.Drawing.Point(136, 76)
        Me.lbl_port.Name = "lbl_port"
        Me.lbl_port.Size = New System.Drawing.Size(30, 12)
        Me.lbl_port.TabIndex = 2
        Me.lbl_port.Text = "COM"
        '
        'lbl_baudrate
        '
        Me.lbl_baudrate.AutoSize = True
        Me.lbl_baudrate.Location = New System.Drawing.Point(197, 76)
        Me.lbl_baudrate.Name = "lbl_baudrate"
        Me.lbl_baudrate.Size = New System.Drawing.Size(52, 12)
        Me.lbl_baudrate.TabIndex = 2
        Me.lbl_baudrate.Text = "ボーレート"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(336, 76)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(61, 12)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "ストップビット"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(417, 76)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(38, 12)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "パリティ"
        '
        'cmb_port1
        '
        Me.cmb_port1.FormattingEnabled = True
        Me.cmb_port1.Location = New System.Drawing.Point(115, 91)
        Me.cmb_port1.Name = "cmb_port1"
        Me.cmb_port1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmb_port1.Size = New System.Drawing.Size(68, 20)
        Me.cmb_port1.TabIndex = 4
        '
        'cmb_baudrate1
        '
        Me.cmb_baudrate1.FormattingEnabled = True
        Me.cmb_baudrate1.Items.AddRange(New Object() {"9600", "19200", "38400", "57600", "115200"})
        Me.cmb_baudrate1.Location = New System.Drawing.Point(186, 91)
        Me.cmb_baudrate1.Name = "cmb_baudrate1"
        Me.cmb_baudrate1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmb_baudrate1.Size = New System.Drawing.Size(68, 20)
        Me.cmb_baudrate1.TabIndex = 4
        '
        'cmb_stopbits1
        '
        Me.cmb_stopbits1.FormattingEnabled = True
        Me.cmb_stopbits1.Items.AddRange(New Object() {"1", "2"})
        Me.cmb_stopbits1.Location = New System.Drawing.Point(329, 91)
        Me.cmb_stopbits1.Name = "cmb_stopbits1"
        Me.cmb_stopbits1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmb_stopbits1.Size = New System.Drawing.Size(68, 20)
        Me.cmb_stopbits1.TabIndex = 4
        '
        'cmb_parity1
        '
        Me.cmb_parity1.FormattingEnabled = True
        Me.cmb_parity1.Items.AddRange(New Object() {"None", "Odd", "Even"})
        Me.cmb_parity1.Location = New System.Drawing.Point(401, 91)
        Me.cmb_parity1.Name = "cmb_parity1"
        Me.cmb_parity1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmb_parity1.Size = New System.Drawing.Size(68, 20)
        Me.cmb_parity1.TabIndex = 4
        '
        'cmb_port2
        '
        Me.cmb_port2.FormattingEnabled = True
        Me.cmb_port2.Location = New System.Drawing.Point(115, 117)
        Me.cmb_port2.Name = "cmb_port2"
        Me.cmb_port2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmb_port2.Size = New System.Drawing.Size(68, 20)
        Me.cmb_port2.TabIndex = 4
        '
        'cmb_baudrate2
        '
        Me.cmb_baudrate2.FormattingEnabled = True
        Me.cmb_baudrate2.Items.AddRange(New Object() {"9600", "19200", "38400", "57600", "115200"})
        Me.cmb_baudrate2.Location = New System.Drawing.Point(186, 117)
        Me.cmb_baudrate2.Name = "cmb_baudrate2"
        Me.cmb_baudrate2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmb_baudrate2.Size = New System.Drawing.Size(68, 20)
        Me.cmb_baudrate2.TabIndex = 4
        '
        'cmb_stopbits2
        '
        Me.cmb_stopbits2.FormattingEnabled = True
        Me.cmb_stopbits2.Items.AddRange(New Object() {"1", "2"})
        Me.cmb_stopbits2.Location = New System.Drawing.Point(329, 117)
        Me.cmb_stopbits2.Name = "cmb_stopbits2"
        Me.cmb_stopbits2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmb_stopbits2.Size = New System.Drawing.Size(68, 20)
        Me.cmb_stopbits2.TabIndex = 4
        '
        'cmb_parity2
        '
        Me.cmb_parity2.FormattingEnabled = True
        Me.cmb_parity2.Items.AddRange(New Object() {"None", "Odd", "Even"})
        Me.cmb_parity2.Location = New System.Drawing.Point(401, 117)
        Me.cmb_parity2.Name = "cmb_parity2"
        Me.cmb_parity2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmb_parity2.Size = New System.Drawing.Size(68, 20)
        Me.cmb_parity2.TabIndex = 4
        '
        'btn_comset1
        '
        Me.btn_comset1.Location = New System.Drawing.Point(477, 90)
        Me.btn_comset1.Name = "btn_comset1"
        Me.btn_comset1.Size = New System.Drawing.Size(65, 23)
        Me.btn_comset1.TabIndex = 5
        Me.btn_comset1.Text = "設定"
        Me.btn_comset1.UseVisualStyleBackColor = True
        '
        'btn_comset2
        '
        Me.btn_comset2.Location = New System.Drawing.Point(477, 115)
        Me.btn_comset2.Name = "btn_comset2"
        Me.btn_comset2.Size = New System.Drawing.Size(65, 23)
        Me.btn_comset2.TabIndex = 5
        Me.btn_comset2.Text = "設定"
        Me.btn_comset2.UseVisualStyleBackColor = True
        '
        'btn_online1
        '
        Me.btn_online1.Location = New System.Drawing.Point(547, 90)
        Me.btn_online1.Name = "btn_online1"
        Me.btn_online1.Size = New System.Drawing.Size(65, 23)
        Me.btn_online1.TabIndex = 5
        Me.btn_online1.Text = "オフライン"
        Me.btn_online1.UseVisualStyleBackColor = True
        '
        'btn_online2
        '
        Me.btn_online2.Location = New System.Drawing.Point(547, 115)
        Me.btn_online2.Name = "btn_online2"
        Me.btn_online2.Size = New System.Drawing.Size(65, 23)
        Me.btn_online2.TabIndex = 5
        Me.btn_online2.Text = "オフライン"
        Me.btn_online2.UseVisualStyleBackColor = True
        '
        'bnt_test
        '
        Me.bnt_test.Location = New System.Drawing.Point(616, 116)
        Me.bnt_test.Name = "bnt_test"
        Me.bnt_test.Size = New System.Drawing.Size(65, 23)
        Me.bnt_test.TabIndex = 5
        Me.bnt_test.Text = "テスト"
        Me.bnt_test.UseVisualStyleBackColor = True
        '
        'btn_monitor
        '
        Me.btn_monitor.Location = New System.Drawing.Point(616, 91)
        Me.btn_monitor.Name = "btn_monitor"
        Me.btn_monitor.Size = New System.Drawing.Size(65, 23)
        Me.btn_monitor.TabIndex = 5
        Me.btn_monitor.Text = "モニター"
        Me.btn_monitor.UseVisualStyleBackColor = True
        '
        'lbl_manutest
        '
        Me.lbl_manutest.AutoSize = True
        Me.lbl_manutest.Location = New System.Drawing.Point(687, 121)
        Me.lbl_manutest.Name = "lbl_manutest"
        Me.lbl_manutest.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lbl_manutest.Size = New System.Drawing.Size(34, 12)
        Me.lbl_manutest.TabIndex = 6
        Me.lbl_manutest.Text = "result"
        '
        'lbl_plcpc
        '
        Me.lbl_plcpc.AutoSize = True
        Me.lbl_plcpc.Location = New System.Drawing.Point(465, 164)
        Me.lbl_plcpc.Name = "lbl_plcpc"
        Me.lbl_plcpc.Size = New System.Drawing.Size(61, 12)
        Me.lbl_plcpc.TabIndex = 6
        Me.lbl_plcpc.Text = "PLC ⇒ PC"
        '
        'lbl_pcplc
        '
        Me.lbl_pcplc.AutoSize = True
        Me.lbl_pcplc.Location = New System.Drawing.Point(579, 163)
        Me.lbl_pcplc.Name = "lbl_pcplc"
        Me.lbl_pcplc.Size = New System.Drawing.Size(61, 12)
        Me.lbl_pcplc.TabIndex = 6
        Me.lbl_pcplc.Text = "PC ⇒ PLC"
        '
        'lst_read
        '
        Me.lst_read.FormattingEnabled = True
        Me.lst_read.ItemHeight = 12
        Me.lst_read.Location = New System.Drawing.Point(507, 179)
        Me.lst_read.Name = "lst_read"
        Me.lst_read.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lst_read.Size = New System.Drawing.Size(59, 136)
        Me.lst_read.TabIndex = 7
        '
        'lst_write
        '
        Me.lst_write.FormattingEnabled = True
        Me.lst_write.ItemHeight = 12
        Me.lst_write.Location = New System.Drawing.Point(622, 179)
        Me.lst_write.Name = "lst_write"
        Me.lst_write.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lst_write.Size = New System.Drawing.Size(59, 136)
        Me.lst_write.TabIndex = 7
        '
        'Timer1
        '
        '
        'lbl_readtop
        '
        Me.lbl_readtop.AutoSize = True
        Me.lbl_readtop.Location = New System.Drawing.Point(467, 179)
        Me.lbl_readtop.Name = "lbl_readtop"
        Me.lbl_readtop.Size = New System.Drawing.Size(38, 12)
        Me.lbl_readtop.TabIndex = 6
        Me.lbl_readtop.Text = "DT500"
        '
        'lbl_writetop
        '
        Me.lbl_writetop.AutoSize = True
        Me.lbl_writetop.Location = New System.Drawing.Point(582, 179)
        Me.lbl_writetop.Name = "lbl_writetop"
        Me.lbl_writetop.Size = New System.Drawing.Size(38, 12)
        Me.lbl_writetop.TabIndex = 6
        Me.lbl_writetop.Text = "DT510"
        '
        'lbl_databits
        '
        Me.lbl_databits.AutoSize = True
        Me.lbl_databits.Location = New System.Drawing.Point(264, 76)
        Me.lbl_databits.Name = "lbl_databits"
        Me.lbl_databits.Size = New System.Drawing.Size(56, 12)
        Me.lbl_databits.TabIndex = 2
        Me.lbl_databits.Text = "データビット"
        '
        'cmb_databits1
        '
        Me.cmb_databits1.FormattingEnabled = True
        Me.cmb_databits1.Items.AddRange(New Object() {"7", "8"})
        Me.cmb_databits1.Location = New System.Drawing.Point(258, 91)
        Me.cmb_databits1.Name = "cmb_databits1"
        Me.cmb_databits1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmb_databits1.Size = New System.Drawing.Size(68, 20)
        Me.cmb_databits1.TabIndex = 4
        '
        'cmb_databits2
        '
        Me.cmb_databits2.FormattingEnabled = True
        Me.cmb_databits2.Items.AddRange(New Object() {"7", "8"})
        Me.cmb_databits2.Location = New System.Drawing.Point(258, 117)
        Me.cmb_databits2.Name = "cmb_databits2"
        Me.cmb_databits2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmb_databits2.Size = New System.Drawing.Size(68, 20)
        Me.cmb_databits2.TabIndex = 4
        '
        'Timer2
        '
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(779, 573)
        Me.Controls.Add(Me.lst_write)
        Me.Controls.Add(Me.lst_read)
        Me.Controls.Add(Me.lbl_pcplc)
        Me.Controls.Add(Me.lbl_writetop)
        Me.Controls.Add(Me.lbl_readtop)
        Me.Controls.Add(Me.lbl_plcpc)
        Me.Controls.Add(Me.lbl_manutest)
        Me.Controls.Add(Me.btn_online2)
        Me.Controls.Add(Me.btn_comset2)
        Me.Controls.Add(Me.btn_monitor)
        Me.Controls.Add(Me.bnt_test)
        Me.Controls.Add(Me.btn_online1)
        Me.Controls.Add(Me.btn_comset1)
        Me.Controls.Add(Me.cmb_parity2)
        Me.Controls.Add(Me.cmb_parity1)
        Me.Controls.Add(Me.cmb_databits2)
        Me.Controls.Add(Me.cmb_stopbits2)
        Me.Controls.Add(Me.cmb_databits1)
        Me.Controls.Add(Me.cmb_stopbits1)
        Me.Controls.Add(Me.cmb_baudrate2)
        Me.Controls.Add(Me.cmb_baudrate1)
        Me.Controls.Add(Me.cmb_port2)
        Me.Controls.Add(Me.cmb_port1)
        Me.Controls.Add(Me.lbl_comset2)
        Me.Controls.Add(Me.lbl_databits)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lbl_baudrate)
        Me.Controls.Add(Me.lbl_port)
        Me.Controls.Add(Me.lbl_comset1)
        Me.Controls.Add(Me.lbl_comset)
        Me.Controls.Add(Me.lbl_title)
        Me.Name = "Form1"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lbl_title As Label
    Friend WithEvents lbl_comset As Label
    Friend WithEvents lbl_comset1 As Label
    Friend WithEvents lbl_comset2 As Label
    Friend WithEvents lbl_port As Label
    Friend WithEvents lbl_baudrate As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents cmb_port1 As ComboBox
    Friend WithEvents cmb_baudrate1 As ComboBox
    Friend WithEvents cmb_stopbits1 As ComboBox
    Friend WithEvents cmb_parity1 As ComboBox
    Friend WithEvents cmb_port2 As ComboBox
    Friend WithEvents cmb_baudrate2 As ComboBox
    Friend WithEvents cmb_stopbits2 As ComboBox
    Friend WithEvents cmb_parity2 As ComboBox
    Friend WithEvents btn_comset1 As Button
    Friend WithEvents btn_comset2 As Button
    Friend WithEvents btn_online1 As Button
    Friend WithEvents btn_online2 As Button
    Friend WithEvents bnt_test As Button
    Friend WithEvents btn_monitor As Button
    Friend WithEvents lbl_manutest As Label
    Friend WithEvents lbl_plcpc As Label
    Friend WithEvents lbl_pcplc As Label
    Friend WithEvents lst_read As ListBox
    Friend WithEvents lst_write As ListBox
    Friend WithEvents Timer1 As Timer
    Friend WithEvents SerialPort1 As IO.Ports.SerialPort
    Friend WithEvents SerialPort2 As IO.Ports.SerialPort
    Friend WithEvents lbl_readtop As Label
    Friend WithEvents lbl_writetop As Label
    Friend WithEvents lbl_databits As Label
    Friend WithEvents cmb_databits1 As ComboBox
    Friend WithEvents cmb_databits2 As ComboBox
    Friend WithEvents Timer2 As Timer
End Class
