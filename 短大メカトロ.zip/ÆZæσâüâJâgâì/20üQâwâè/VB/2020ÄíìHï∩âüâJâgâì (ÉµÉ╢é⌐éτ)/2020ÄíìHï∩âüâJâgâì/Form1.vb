﻿Public Class Form1


    Dim plcComBusyFlag As Boolean

    '★★★　タイマー関連プログラム　★★★　タイマーセット～タイムアップチェック、指定時間待ち   Timer1 を使用　　-----------------------------

    Dim tm As Integer                   'Timerの現在値管理用変数

    'タイマー起動
    Private Sub timinit()
        Timer1.Interval = 10
        Timer1.Enabled = True
    End Sub

    'インターバル10msで、タイマー用データをディクリメント
    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        If tm > 0 Then tm = tm - 1
    End Sub

    '時間を指定してタイマをセット（timchkとセットで使用する）　　tdt：待ち時間　　
    Private Sub timset(ByVal tdt As Integer)
        tm = tdt
    End Sub

    'タイムアップをチェック（timsetとセットで使用する）
    Private Function timchk() As Integer
        Return tm
    End Function

    '時間を指定してタイムアップまで待つ　　　tdt：待ち時間
    Private Sub timwait(ByVal tdt As Integer)
        timset(tdt)
        While timchk() <> 0
            Windows.Forms.Application.DoEvents()
        End While
    End Sub


    '★★★　ビットセット、クリア、テスト　★★★　16bitのデータを対象としたビットコントロール ---------------------------------------------------
    ' 指定ビットをON
    Public Function bset(ByVal dt As Integer, ByVal b As Integer) As Integer
        If (b >= 0) And (b <= 15) Then
            Return dt Or (2 ^ b)
        Else
            Return dt
        End If
    End Function

    '指定ビットをOFF
    Public Function bclr(ByVal dt As Integer, ByVal b As Integer) As Integer
        If (b >= 0) And (b <= 15) Then
            Return dt And (Not (2 ^ b))
        Else
            Return dt
        End If
    End Function

    '指定ビットをON/OFFをテスト
    Public Function btst(ByVal dt As Integer, ByVal b As Integer) As Boolean
        If (b >= 0) And (b <= 15) Then
            If (dt And (2 ^ b)) <> 0 Then
                Return True
            End If
        End If
        Return False
    End Function


    '★★★　PLCリンク用シリアル通信ポートの設定　★★★　Serial.Port1を使用    //////////////////////////////////////////////////////////

    'PLCリンクポートの設定用コンボボックスアイテムのデフォルト設定
    Private Sub comboBoxInit1()
        port1_search()
        cmb_port1.SelectedIndex = cmb_port1.Items.Count - 1 'コンボボックス一番下のアイテム
        cmb_baudrate1.SelectedIndex = 2     '38400
        cmb_databits1.SelectedIndex = 1     '8
        cmb_stopbits1.SelectedIndex = 0     '1
        cmb_parity1.SelectedIndex = 1       'Odd
    End Sub

    'PLCリンクシリアルポート設定用にCOM番号をリストアップ
    Private Sub port1_search()
        cmb_port1.Items.Clear()
        For Each sp As String In My.Computer.Ports.SerialPortNames
            cmb_port1.Items.Add(sp)   'アイテムを追加
        Next
    End Sub

    '通信ポート設定　マウスクリックでコンボボックスにCOM番号を表示
    Private Sub cmb_port1_click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmb_port1.MouseClick
        port1_search()
    End Sub

    'PLCリンク用シリアルポートの設定
    Private Sub btn_comset1_Click(sender As Object, e As EventArgs) Handles btn_comset1.Click
        If SerialPort1.IsOpen Then
            MsgBox("ポートが開いているので設定変更できませんでした")
            Exit Sub
        End If
        Select Case cmb_baudrate1.SelectedItem
            Case "9600"
                SerialPort1.BaudRate = "9600"
            Case "19200"
                SerialPort1.BaudRate = "19200"
            Case "38400"
                SerialPort1.BaudRate = "38400"
            Case "57600"
                SerialPort1.BaudRate = "57600"
            Case "115200"
                SerialPort1.BaudRate = "115200"
        End Select

        Select Case cmb_databits1.SelectedItem
            Case "7"
                SerialPort1.DataBits = 7
            Case "8"
                SerialPort1.DataBits = 8
        End Select

        Select Case cmb_stopbits1.SelectedItem
            Case "1"
                SerialPort1.StopBits = IO.Ports.StopBits.One
            Case "2"
                SerialPort1.StopBits = IO.Ports.StopBits.Two
        End Select

        Select Case cmb_parity1.SelectedItem
            Case "None"
                SerialPort1.Parity = IO.Ports.Parity.None
            Case "Odd"
                SerialPort1.Parity = IO.Ports.Parity.Odd
            Case "Even"
                SerialPort1.Parity = IO.Ports.Parity.Even
        End Select

        SerialPort1.PortName = cmb_port1.SelectedItem
        SerialPort1.ReadTimeout = 1000
        SerialPort1.WriteTimeout = 1000
    End Sub

    'PLCリンク用シリアルポートシリアルポートのオンライン/オフライン切り替え
    Private Sub btn_online1_Click(sender As Object, e As EventArgs) Handles btn_online1.Click
        If SerialPort1.IsOpen Then
            Try
                SerialPort1.Close()
                btn_online1.BackColor = Color.LightGray
                btn_online1.Text = "オフライン"
                Timer2.Enabled = False
                Exit Sub
            Catch ex As Exception
                MsgBox("Port1 Close Error: " & ex.Message)
            End Try
        Else
            Try
                SerialPort1.Open()
                btn_online1.BackColor = Color.Lime
                btn_online1.Text = "オンライン"
                Timer2.Enabled = True
            Catch ex As Exception
                MsgBox("Port1 Open Error: " & ex.Message)
            End Try
        End If
    End Sub

    '★★★　PLCリンクデータの表示プログラム　★★★  ----------------------------

    'PLCとのリンクデータ表示／非表示切り替え
    Private Sub btn_monitor_Click(sender As Object, e As EventArgs) Handles btn_monitor.Click
        If lst_read.Visible = True Then
            monitorInvisible()
        Else
            monitorVisible()
        End If
    End Sub

    'PLCとのリンクデータ非表示
    Private Sub monitorInvisible()
        lst_read.Visible = False
        lst_write.Visible = False
        lbl_plcpc.Visible = False
        lbl_pcplc.Visible = False
        lbl_readtop.Visible = False
        lbl_writetop.Visible = False
        lbl_manutest.Text = ""
    End Sub

    'PLCとのリンクデータ表示
    Private Sub monitorVisible()
        lst_read.Visible = True
        lst_write.Visible = True
        lbl_plcpc.Visible = True
        lbl_pcplc.Visible = True
        lbl_readtop.Visible = True
        lbl_writetop.Visible = True
    End Sub

    '★★★　ＰＬＣとの通信プログラム　★★★　MEWTOCOL-COM対応    -------------------------------------------------------------------------------

    Dim plc_num As String = "01"
    Dim sd_code As String = "D"
    Dim rd_code As String = "D"
    Dim rd_top_ad As Integer = 500
    Dim sd_top_ad As Integer = 510
    Dim comDataSize As Integer = 10     'ＰＬＣリンクデータのサイズ

    Dim rd_data(comDataSize - 1) As Short           '受信データ格納用変数
    Dim sd_data(comDataSize - 1) As Short           '送信データ格納用変数

    'データ送信 comDataSizeワード
    Private Function s_sunxdata() As String

        Dim top_ad, btm_ad As String
        Dim sd_str1, sd_str2, Str As String

        '先頭と最終のワードNoを計算 → 5文字で
        top_ad = Convert.ToString(sd_top_ad)
        top_ad = StrDup(5 - Len(top_ad), "0"c) & top_ad
        btm_ad = Convert.ToString(sd_top_ad + comDataSize - 1)
        btm_ad = StrDup(5 - Len(btm_ad), "0"c) & btm_ad

        'データライト時の送信データ作成
        sd_str1 = "%" & plc_num & "#WD" & sd_code & top_ad & btm_ad
        For i = 0 To comDataSize - 1
            Str = Convert.ToString(sd_data(i), 16)
            If Len(Str) < 4 Then
                Str = StrDup(4 - Len(Str), "0"c) & Str
            ElseIf Len(Str) > 4 Then
                'Str = Str.Substring(4)         'どちらでもよい（４文字目までをカット）
                Str = Strings.Right(Str, 4)     'どちらでもよい（右から４文字を抽出）
            End If
            sd_str1 = sd_str1 & swap(Str)
        Next
        sd_str1 = sd_str1.ToUpper         '大文字変換
        sd_str1 = sd_str1 & bcc(sd_str1)   'BCC付与

        Try
            SerialPort1.Write(sd_str1 & vbCr)
        Catch ex As Exception
            'MsgBox("SerialPort Send Timeout-1 !")
            Return "SerialPort Send Timeout-1 !"
        End Try

        Try
            sd_str2 = SerialPort1.ReadTo(vbCr)
        Catch ex As Exception
            'MsgBox("SerialPort Receive Timeout-1 !")
            Return "SerialPort Receive Timeout-1 !"
        End Try

        If Len(sd_str2) <> 8 Then
            MsgBox("SerialPort WD response data size error " & Len(sd_str2))
        ElseIf Mid(sd_str2, 5, 2) <> "WD" Then
            MsgBox("SerialPort WD response error No." & Mid(sd_str2, 5, 2))
        End If

        Return sd_str1 & vbCrLf & sd_str2
    End Function

    'データ受信 comDataSizeワード
    Private Function r_sunxdata() As String
        Dim i As Integer

        Dim rd_str1, rd_str2 As String
        Dim top_ad, btm_ad As String

        '先頭と最終のワードNoを計算 → 5文字で
        top_ad = Convert.ToString(rd_top_ad)
        top_ad = StrDup(5 - Len(top_ad), "0"c) & top_ad
        btm_ad = Convert.ToString(rd_top_ad + comDataSize - 1)
        btm_ad = StrDup(5 - Len(btm_ad), "0"c) & btm_ad

        'データリード時の送信データ作成
        rd_str1 = "%" & plc_num & "#RD" & rd_code & top_ad & btm_ad
        rd_str1 = rd_str1.ToUpper         '大文字変換
        rd_str1 = rd_str1 & bcc(rd_str1)   'BCC付与

        Try
            SerialPort1.Write(rd_str1 & vbCr)
        Catch ex As Exception
            MsgBox("SerialPort Send Timeout-2 !" & rd_str1)
            Return "SerialPort Send Timeout-2 !"
        End Try

        Try
            rd_str2 = SerialPort1.ReadTo(vbCr)
        Catch ex As Exception
            'MsgBox("SerialPort Receive Timeout-2 !")
            Return "SerialPort Receive Timeout-2 !"
        End Try

        '読み出しデータのチェック　　データサイズとBCCをチェック
        If Len(rd_str2) <> (comDataSize * 4 + 8) Then
            'MsgBox("SerialPort RD response data size error " & Len(rd_str2))
            Return "SerialPort RD response data size error " & Len(rd_str2)
        ElseIf Mid(rd_str2, 5, 2) <> "RD" Then
            'MsgBox("SerialPort RD response error No." & Mid(rd_str2, 5, 2))
            Return "SerialPort RD response error No." & Mid(rd_str2, 5, 2)
        ElseIf Mid(rd_str2, comDataSize * 4 + 7, 2) <> bcc(Mid(rd_str2, 1, comDataSize * 4 + 6)) Then
            MsgBox("SerialPort RD response bcc error ")
            Return "SerialPort RD response bcc error "
        End If

        'データ読込
        For i = 0 To comDataSize - 1
            rd_data(i) = Convert.ToInt16(swap(Mid(rd_str2, 7 + i * 4, 4)), 16)
        Next

        Return rd_str1 & vbCrLf & rd_str2
    End Function

    'BCC計算
    Private Function bcc(ByVal str As String) As String
        Dim tmp As Integer = 0
        Dim tmp_u, tmp_l As Integer
        Dim i As Integer

        For i = 1 To Len(str)
            tmp = tmp Xor Asc(Strings.Mid(str, i, 1))
        Next
        tmp = tmp And &HFF
        tmp_u = (tmp >> 4) + &H30
        If tmp_u > &H39 Then tmp_u = tmp_u + 7
        tmp_l = (tmp And &HF) + &H30
        If tmp_l > &H39 Then tmp_l = tmp_l + 7
        Return Chr(tmp_u) & Chr(tmp_l)
    End Function

    '4文字の上位・下位入れ替え
    Private Function swap(ByVal dt As String) As String
        Dim up, lw As String
        lw = Strings.Right(dt, 2)
        up = Strings.Left(dt, 2)
        Return lw & up
    End Function

    'ＰＬＣとのリンクエリアを０クリア
    Private Sub comDataInit()
        Dim i As Integer

        For i = 0 To comDataSize - 1
            rd_data(i) = 0      'ＰＬＣからの読出しエリア０クリア
            sd_data(i) = 0      'ＰＬＣへの書き込みエリアの０クリア
        Next
    End Sub

    'ＰＬＣとのデータ送受信
    '
    ' （★参考）Timer.Tickでの実行結果
    '	TimerInterval / BaudRate / 100CountTestResult
    '	10 / 115200 / 35sec
    '	50 / 38400 / 25sec★-----今回のデフォルトとする
    '	100 / 19200 / 43sec
    '	200 / 9600 / 86sec
    ' （★参考）データ送受信に必要なタイミングだけ通信
    '	BaudRate / 100CountTestResult
    '	38400 / 18sec
    '
    Private Sub plcCom()
        r_sunxdata()               'ＰＬＣのデータ読み込み
        For i = 0 To comDataSize - 1
            lst_read.Items(i) = rd_data(i)      'ＰＬＣ読込みエリアのデータをリストボックスに表示
        Next

        s_sunxdata()               'ＰＬＣにデータ書き込み
        For i = 0 To comDataSize - 1
            lst_write.Items(i) = sd_data(i)     'ＰＬＣ書込みエリアのデータをリストボックスに表示
        Next
    End Sub

    'PLCリンクデータの表示用リストボックスの初期化
    '   エリアサイズ分のアイテムを作成し、値を０クリアする
    Private Sub lstReadWriteInit()
        lst_read.Items.Clear()
        lst_write.Items.Clear()

        For i = 0 To comDataSize - 1
            lst_read.Items.Add(0)       'ＰＬＣ読み込みエリアの初期化
            lst_write.Items.Add(0)      'ＰＬＣ書込みエリアの初期化
        Next
    End Sub


    'ＰＬＣとのデータ送受信の実行　Timer2 を使用して一定周期で plcCom() を実行  ------------------------------------------------------------------

    Private Sub timinit2()
        Timer2.Interval = 50    '★もし不具合がでるようであればチューニング
        Timer2.Enabled = False
    End Sub

    '設定されたインターバルでＰＬＣとのデータ送受信を実行
    Private Sub Timer2_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer2.Tick
        If plcComBusyFlag = True Then Exit Sub      '前回のTimer2_Tickでの通信が終了していない場合は以降の処理を行わない

        plcComBusyFlag = True
        plcCom()                                    '★PLCとの送受信★
        plcComBusyFlag = False

    End Sub



    '★★★　デジタルパネルメータ接続用シリアル通信ポートの設定　★★★　Serial.Port2を使用    /////////////////////////////////////////////////

    'デジタルパネルメータ接続ポートの設定用コンボボックスアイテムのデフォルト設定
    Private Sub comboBoxInit2()
        port2_search()
        cmb_port2.SelectedIndex = cmb_port2.Items.Count - 1 'コンボボックス一番下のアイテム
        cmb_baudrate2.SelectedIndex = 0     '9600
        cmb_databits2.SelectedIndex = 0     '7
        cmb_stopbits2.SelectedIndex = 1     '1
        cmb_parity2.SelectedIndex = 2       'Even
    End Sub

    'デジタルパネル接続シリアルポート設定用にCOM番号をリストアップ
    Private Sub port2_search()
        cmb_port2.Items.Clear()
        For Each sp As String In My.Computer.Ports.SerialPortNames
            cmb_port2.Items.Add(sp)   'アイテムを追加
        Next
    End Sub

    '通信ポート設定　マウスクリックでコンボボックスにCOM番号を表示
    Private Sub cmb_port2_click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmb_port2.MouseClick
        port2_search()
    End Sub

    'デジタルパネルメータ接続用シリアルポートの設定
    Private Sub btn_comset2_Click(sender As Object, e As EventArgs) Handles btn_comset2.Click
        If SerialPort2.IsOpen Then
            MsgBox("ポートが開いているので設定変更できませんでした")
            Exit Sub
        End If

        Select Case cmb_baudrate2.SelectedItem
            Case "9600"
                SerialPort2.BaudRate = "9600"
            Case "19200"
                SerialPort2.BaudRate = "19200"
            Case "38400"
                SerialPort2.BaudRate = "38400"
            Case "57600"
                SerialPort2.BaudRate = "57600"
            Case "115200"
                SerialPort2.BaudRate = "115200"
        End Select

        Select Case cmb_databits2.SelectedItem
            Case "7"
                SerialPort2.DataBits = 7
            Case "8"
                SerialPort2.DataBits = 8
        End Select

        Select Case cmb_stopbits2.SelectedItem
            Case "1"
                SerialPort2.StopBits = IO.Ports.StopBits.One
            Case "2"
                SerialPort2.StopBits = IO.Ports.StopBits.Two
        End Select

        Select Case cmb_parity2.SelectedItem
            Case "None"
                SerialPort2.Parity = IO.Ports.Parity.None
            Case "Odd"
                SerialPort2.Parity = IO.Ports.Parity.Odd
            Case "Even"
                SerialPort2.Parity = IO.Ports.Parity.Even
        End Select

        SerialPort2.PortName = cmb_port2.SelectedItem
        SerialPort2.ReadTimeout = 1000
        SerialPort2.WriteTimeout = 1000
    End Sub

    'デジタルパネルメータ接続用のオンライン/オフライン切り替え
    Private Sub btn_online2_Click(sender As Object, e As EventArgs) Handles btn_online2.Click
        If SerialPort2.IsOpen Then
            Try
                SerialPort2.Close()
                btn_online2.BackColor = Color.LightGray
                btn_online2.Text = "オフライン"
            Catch ex As Exception
                MsgBox("Port2 Close Error: " & ex.Message)
            End Try
        Else
            Try
                SerialPort2.Open()
                btn_online2.BackColor = Color.Lime
                btn_online2.Text = "オンライン"
            Catch ex As Exception
                MsgBox("Port2 Open Error: " & ex.Message)
            End Try
        End If
    End Sub


    '★★★　デジタルパネルメータ通信プログラム　★★★　CompoWay/F対応     ------------------------------------------------------------------------

    'OMRON K3HB コマンド送信要素
    Dim NODE As String = "01"       'ノードNo.
    Dim SUB_AD As String = "00"     'サブアドレス（未使用：00を指定）
    Dim SID As String = "0"         'サービスID（未使用：0を指定）
    Dim STX As String = Chr(&H2)    '通信フレームの先頭コード
    Dim ETX As String = Chr(&H3)    'テキストの終了コード
    Dim MRC As String = "01"        'メインリクエストコード（モニタ値読出し：01）
    Dim SRC As String = "01"        'サブリクエストコード（モニタ値読出し：01）
    Dim KIND As String = "C0"       '変数種別（モニタ値読出し：C0）
    Dim ADRS As String = "0002"     'アドレス（計測値：0002）
    Dim BIT As String = "00"        'ビット位置（00）
    Dim ITEM As String = "0001"     '要素数（0001）

    'ブロックチェックキャラクタ計算（CompoWay/F）　ノードNoからETXまでのBCCを計算
    Private Function bcc_omron(ByVal dt As String) As String
        Dim i As Integer
        Dim bcc As Integer = &H0

        For i = 2 To Len(dt)
            bcc = bcc Xor Asc(Mid(dt, i, 1))
        Next
        Return Chr(bcc)

    End Function

    'データライト sd_sizeワード
    Private Function s_omrondata() As Single

        Dim CMD, CMD_TXT As String
        Dim sd_str As String

        CMD = KIND & ADRS & BIT & ITEM
        CMD_TXT = MRC & SRC & CMD
        sd_str = STX & NODE & SUB_AD & SID & CMD_TXT & ETX
        sd_str = sd_str & bcc_omron(sd_str)

        Try
            SerialPort2.Write(sd_str)
        Catch ex As Exception
            MsgBox("SerialPort Send Error: " & ex.Message)
            Return -1   '例外発生
        End Try
        Return 0

    End Function

    'データリード rd_sizeワード
    Private Function r_omrondata() As Single

        Dim rcv_str As String
        Dim rcv_val As Single
        Dim r_node, r_subAdrs, r_MRC, r_SRC, r_endCode, r_ResCode, r_data As String

        Try
            timset(100)
            Do Until SerialPort2.BytesToRead = 25
                Application.DoEvents()
                If timchk() = 0 Then
                    MsgBox("SerialPort Receive Timeout !")
                    rcv_str = SerialPort2.ReadExisting()
                    Return -2   '受信データタイムアウト（受信バイト数不足）
                End If
            Loop

            rcv_str = SerialPort2.ReadExisting()

        Catch ex As Exception
            MsgBox("SerialPort Receive Error: " & ex.Message)
            Return -1   '例外発生
        End Try

        r_node = Mid(rcv_str, 2, 2)         '受信データよりノードNo取出し
        r_subAdrs = Mid(rcv_str, 4, 2)      '受信データよりサブアドレス取出し
        r_endCode = Mid(rcv_str, 6, 2)      '受信データより終了コード取出し
        r_MRC = Mid(rcv_str, 8, 2)          '受信データよりMRC取出し
        r_SRC = Mid(rcv_str, 10, 2)         '受信データよりSRC取出し
        r_ResCode = Mid(rcv_str, 12, 4)     '受信データよりレスポンスコード取出し
        r_data = Mid(rcv_str, 16, 8)        '受信データより計測データ取出し

        'txt_rcvstr.Text = txt_rcvstr.Text & rcv_str & vbCrLf    '受信データ表示

        '受信データチェック（正常時は、終了コード="00"、レスポンスコード="0000"）
        If (r_endCode <> "00") Or (r_ResCode <> "0000") Then
            MsgBox("SerialPort Receive Error  EndCode:" & r_endCode & ", ResCode:" & r_ResCode)
            Return -3   '異常レスポンスあり
        End If

        '測定データの値への変換　　16進数の文字列を整数にコンバート後、桁数を合わせてSingleに
        rcv_val = Convert.ToInt32(r_data, 16) / 100
        'txt_rcvval.Text = txt_rcvval.Text & rcv_val & vbCrLf

        Return rcv_val

    End Function

    'マニュアル測定
    Private Sub bnt_test_Click(sender As Object, e As EventArgs) Handles bnt_test.Click
        Dim result As Single

        lbl_manutest.Text = ""

        If SerialPort2.IsOpen Then
            result = s_omrondata()      'コマンド送信
            If result <> 0 Then
                lbl_manutest.Text = "Send Error"
                Exit Sub
            End If
            result = r_omrondata()      'レスポンス受信
            If result < 0 Then
                lbl_manutest.Text = "Receive Error"
            Else
                lbl_manutest.Text = Format(result, "0.00")
            End If
        End If
    End Sub



    ' ★★★　主要なアプリケーションプログラム　★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★

    'フォームロード
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        timinit()               'Timer1の初期化　　汎用

        timinit2()              'Timer2の初期化　　PLCとのデータ送受信用
        lstReadWriteInit()      'PLCリンクデータ表示用リストボックスを初期化
        monitorInvisible()      'PLCリンクデータ表示用リストボックスを非表示
        comboBoxInit1()         'PLCリンク用シリアルポート（Serial.Port1）の設定用コンボボックスにデフォルトを設定

        comboBoxInit2()         'デジタルパネルメータ接続用シリアルポート（Serial.Port2）の設定用コンボボックスにデフォルトを設定

    End Sub





End Class
