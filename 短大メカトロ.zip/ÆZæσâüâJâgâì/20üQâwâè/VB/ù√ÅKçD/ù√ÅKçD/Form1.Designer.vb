﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lbl_sum1 = New System.Windows.Forms.Label()
        Me.lbl_sum2 = New System.Windows.Forms.Label()
        Me.lbl_sum3 = New System.Windows.Forms.Label()
        Me.txt_start = New System.Windows.Forms.TextBox()
        Me.txt_end = New System.Windows.Forms.TextBox()
        Me.btn_sum1 = New System.Windows.Forms.Button()
        Me.btn_sum2 = New System.Windows.Forms.Button()
        Me.btn_sum3 = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.btn_exit = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(22, 66)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(61, 20)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "START"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(251, 66)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(43, 20)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "END"
        '
        'lbl_sum1
        '
        Me.lbl_sum1.AutoSize = True
        Me.lbl_sum1.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_sum1.Location = New System.Drawing.Point(149, 19)
        Me.lbl_sum1.Name = "lbl_sum1"
        Me.lbl_sum1.Size = New System.Drawing.Size(144, 37)
        Me.lbl_sum1.TabIndex = 5
        Me.lbl_sum1.Text = "lbl_sum1"
        Me.lbl_sum1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lbl_sum2
        '
        Me.lbl_sum2.AutoSize = True
        Me.lbl_sum2.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_sum2.Location = New System.Drawing.Point(149, 79)
        Me.lbl_sum2.Name = "lbl_sum2"
        Me.lbl_sum2.Size = New System.Drawing.Size(146, 37)
        Me.lbl_sum2.TabIndex = 6
        Me.lbl_sum2.Text = "lbl_sum2"
        Me.lbl_sum2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lbl_sum3
        '
        Me.lbl_sum3.AutoSize = True
        Me.lbl_sum3.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_sum3.Location = New System.Drawing.Point(149, 150)
        Me.lbl_sum3.Name = "lbl_sum3"
        Me.lbl_sum3.Size = New System.Drawing.Size(146, 37)
        Me.lbl_sum3.TabIndex = 7
        Me.lbl_sum3.Text = "lbl_sum3"
        Me.lbl_sum3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txt_start
        '
        Me.txt_start.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_start.Location = New System.Drawing.Point(89, 59)
        Me.txt_start.Name = "txt_start"
        Me.txt_start.Size = New System.Drawing.Size(100, 31)
        Me.txt_start.TabIndex = 0
        Me.txt_start.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txt_end
        '
        Me.txt_end.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_end.Location = New System.Drawing.Point(300, 59)
        Me.txt_end.Name = "txt_end"
        Me.txt_end.Size = New System.Drawing.Size(100, 31)
        Me.txt_end.TabIndex = 1
        Me.txt_end.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'btn_sum1
        '
        Me.btn_sum1.Font = New System.Drawing.Font("MS UI Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.btn_sum1.Location = New System.Drawing.Point(38, 122)
        Me.btn_sum1.Name = "btn_sum1"
        Me.btn_sum1.Size = New System.Drawing.Size(110, 38)
        Me.btn_sum1.TabIndex = 2
        Me.btn_sum1.Text = "SUM 1"
        Me.btn_sum1.UseVisualStyleBackColor = True
        '
        'btn_sum2
        '
        Me.btn_sum2.Font = New System.Drawing.Font("MS UI Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.btn_sum2.Location = New System.Drawing.Point(38, 188)
        Me.btn_sum2.Name = "btn_sum2"
        Me.btn_sum2.Size = New System.Drawing.Size(110, 37)
        Me.btn_sum2.TabIndex = 3
        Me.btn_sum2.Text = "SUM 2"
        Me.btn_sum2.UseVisualStyleBackColor = True
        '
        'btn_sum3
        '
        Me.btn_sum3.Font = New System.Drawing.Font("MS UI Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.btn_sum3.Location = New System.Drawing.Point(38, 252)
        Me.btn_sum3.Name = "btn_sum3"
        Me.btn_sum3.Size = New System.Drawing.Size(110, 39)
        Me.btn_sum3.TabIndex = 4
        Me.btn_sum3.Text = "SUM 3"
        Me.btn_sum3.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.lbl_sum2)
        Me.GroupBox1.Controls.Add(Me.lbl_sum1)
        Me.GroupBox1.Controls.Add(Me.lbl_sum3)
        Me.GroupBox1.Location = New System.Drawing.Point(26, 104)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(326, 215)
        Me.GroupBox1.TabIndex = 8
        Me.GroupBox1.TabStop = False
        '
        'btn_exit
        '
        Me.btn_exit.Location = New System.Drawing.Point(358, 271)
        Me.btn_exit.Name = "btn_exit"
        Me.btn_exit.Size = New System.Drawing.Size(75, 48)
        Me.btn_exit.TabIndex = 9
        Me.btn_exit.Text = "END"
        Me.btn_exit.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("HGP創英角ｺﾞｼｯｸUB", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label3.Location = New System.Drawing.Point(21, 9)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(93, 27)
        Me.Label3.TabIndex = 10
        Me.Label3.Text = "練習⑤"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(435, 331)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.btn_exit)
        Me.Controls.Add(Me.btn_sum3)
        Me.Controls.Add(Me.btn_sum2)
        Me.Controls.Add(Me.btn_sum1)
        Me.Controls.Add(Me.txt_end)
        Me.Controls.Add(Me.txt_start)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "Form1"
        Me.Text = "練習⑤"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents lbl_sum1 As Label
    Friend WithEvents lbl_sum2 As Label
    Friend WithEvents lbl_sum3 As Label
    Friend WithEvents txt_start As TextBox
    Friend WithEvents txt_end As TextBox
    Friend WithEvents btn_sum1 As Button
    Friend WithEvents btn_sum2 As Button
    Friend WithEvents btn_sum3 As Button
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents btn_exit As Button
    Friend WithEvents Label3 As Label
End Class
