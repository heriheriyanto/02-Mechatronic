﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        txt_start.Text = ""
        txt_end.Text = ""
        lbl_sum1.Text = ""
        lbl_sum2.Text = ""
        lbl_sum3.Text = ""
        txt_start.Select()
    End Sub

    Private Sub btn_sum1_Click(sender As Object, e As EventArgs) Handles btn_sum1.Click
        Dim startValue, endValue, sum, count As Integer

        sum = 0
        startValue = Val(txt_start.Text)
        endValue = Val(txt_end.Text)
        For count = 1 To endValue
            sum = sum + count
        Next

        lbl_sum1.Text = sum

    End Sub

    Private Sub btn_sum2_Click(sender As Object, e As EventArgs) Handles btn_sum2.Click
        Dim startValue, endValue, sum, count As Integer

        sum = 0
        startValue = Val(txt_start.Text)
        endValue = Val(txt_end.Text)
        For count = startValue To endValue
            sum = sum + count
        Next

        lbl_sum2.Text = sum
    End Sub

    Private Sub btn_sum3_Click(sender As Object, e As EventArgs) Handles btn_sum3.Click
        Dim startValue, endValue, sum, count As Integer

        If Not IsNumeric(txt_start.Text) Or Not IsNumeric(txt_end.Text) Then
            MsgBox("Please input number !!")
            Exit Sub
        End If

        sum = 0
        startValue = Val(txt_start.Text)
        endValue = Val(txt_end.Text)
        For count = startValue To endValue
            sum = sum + count
        Next

        lbl_sum3.Text = sum
    End Sub

    Private Sub btn_exit_Click(sender As Object, e As EventArgs) Handles btn_exit.Click
        If MsgBox("Are you sure want to Exit ?", vbOKCancel) = vbOK Then
            Close()
        Else
            Exit Sub
        End If
    End Sub

End Class
