﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_String
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btn_exit = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txt_input = New System.Windows.Forms.TextBox()
        Me.btn_clear = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lbl_output = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.combo_opr = New System.Windows.Forms.ComboBox()
        Me.btn_opr = New System.Windows.Forms.Button()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.lbl_char_2 = New System.Windows.Forms.Label()
        Me.txt_opr_1 = New System.Windows.Forms.TextBox()
        Me.txt_opr_2 = New System.Windows.Forms.TextBox()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'btn_exit
        '
        Me.btn_exit.Location = New System.Drawing.Point(584, 386)
        Me.btn_exit.Name = "btn_exit"
        Me.btn_exit.Size = New System.Drawing.Size(75, 23)
        Me.btn_exit.TabIndex = 0
        Me.btn_exit.Text = "Exit String"
        Me.btn_exit.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(25, 37)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(103, 24)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Input Text :"
        '
        'txt_input
        '
        Me.txt_input.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_input.Location = New System.Drawing.Point(136, 28)
        Me.txt_input.Name = "txt_input"
        Me.txt_input.Size = New System.Drawing.Size(479, 44)
        Me.txt_input.TabIndex = 2
        '
        'btn_clear
        '
        Me.btn_clear.Location = New System.Drawing.Point(622, 28)
        Me.btn_clear.Name = "btn_clear"
        Me.btn_clear.Size = New System.Drawing.Size(47, 44)
        Me.btn_clear.TabIndex = 3
        Me.btn_clear.Text = "Clear Text"
        Me.btn_clear.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(32, 111)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(96, 24)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Output     :"
        '
        'lbl_output
        '
        Me.lbl_output.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lbl_output.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_output.Location = New System.Drawing.Point(134, 90)
        Me.lbl_output.Name = "lbl_output"
        Me.lbl_output.Size = New System.Drawing.Size(481, 45)
        Me.lbl_output.TabIndex = 1
        Me.lbl_output.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.txt_opr_2)
        Me.GroupBox1.Controls.Add(Me.txt_opr_1)
        Me.GroupBox1.Controls.Add(Me.lbl_char_2)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.btn_opr)
        Me.GroupBox1.Controls.Add(Me.combo_opr)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(29, 183)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(227, 144)
        Me.GroupBox1.TabIndex = 4
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Operation"
        '
        'combo_opr
        '
        Me.combo_opr.FormattingEnabled = True
        Me.combo_opr.Items.AddRange(New Object() {"LEFT", "RIGHT", "MID"})
        Me.combo_opr.Location = New System.Drawing.Point(7, 36)
        Me.combo_opr.Name = "combo_opr"
        Me.combo_opr.Size = New System.Drawing.Size(122, 28)
        Me.combo_opr.TabIndex = 0
        '
        'btn_opr
        '
        Me.btn_opr.Location = New System.Drawing.Point(145, 43)
        Me.btn_opr.Name = "btn_opr"
        Me.btn_opr.Size = New System.Drawing.Size(67, 56)
        Me.btn_opr.TabIndex = 1
        Me.btn_opr.Text = "OK"
        Me.btn_opr.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(6, 74)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(49, 20)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "char1"
        '
        'lbl_char_2
        '
        Me.lbl_char_2.AutoSize = True
        Me.lbl_char_2.Location = New System.Drawing.Point(6, 108)
        Me.lbl_char_2.Name = "lbl_char_2"
        Me.lbl_char_2.Size = New System.Drawing.Size(49, 20)
        Me.lbl_char_2.TabIndex = 3
        Me.lbl_char_2.Text = "char2"
        '
        'txt_opr_1
        '
        Me.txt_opr_1.Location = New System.Drawing.Point(61, 68)
        Me.txt_opr_1.Name = "txt_opr_1"
        Me.txt_opr_1.Size = New System.Drawing.Size(68, 26)
        Me.txt_opr_1.TabIndex = 4
        Me.txt_opr_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txt_opr_2
        '
        Me.txt_opr_2.Location = New System.Drawing.Point(61, 101)
        Me.txt_opr_2.Name = "txt_opr_2"
        Me.txt_opr_2.Size = New System.Drawing.Size(68, 26)
        Me.txt_opr_2.TabIndex = 4
        Me.txt_opr_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'frm_String
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(681, 431)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.btn_clear)
        Me.Controls.Add(Me.txt_input)
        Me.Controls.Add(Me.lbl_output)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btn_exit)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "frm_String"
        Me.Text = "frm_String"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btn_exit As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents txt_input As TextBox
    Friend WithEvents btn_clear As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents lbl_output As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents combo_opr As ComboBox
    Friend WithEvents txt_opr_2 As TextBox
    Friend WithEvents txt_opr_1 As TextBox
    Friend WithEvents lbl_char_2 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents btn_opr As Button
End Class
