﻿Public Class frm_String
    Private Sub btn_exit_Click(sender As Object, e As EventArgs) Handles btn_exit.Click
        Close()
    End Sub

    Private Sub btn_clear_Click(sender As Object, e As EventArgs) Handles btn_clear.Click
        txt_input.Text = ""
        lbl_output.Text = ""
        combo_opr.Text = ""
        txt_opr_1.Text = ""
    End Sub

    Private Sub frm_String_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        txt_opr_2.Enabled = False
        lbl_char_2.Enabled = False
    End Sub

    Private Sub btn_opr_Click(sender As Object, e As EventArgs) Handles btn_opr.Click
        Select Case combo_opr.Text
            Case "LEFT"
                Call LeftChar()
        End Select
    End Sub

    Sub LeftChar()
        If Not IsNumeric(txt_opr_1.Text) Then
            MsgBox("Please input number at [char1] box !")
            Exit Sub
        End If
        lbl_output.Text = Microsoft.VisualBasic.Left(txt_input.Text, Val(txt_opr_1.Text))
    End Sub
End Class