﻿Public Class frm_Main
    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        If MsgBox("Are you sure want to Exit ?", vbOKCancel) = vbOK Then
            Close()
        Else
            Exit Sub
        End If
    End Sub

    Private Sub SumToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SumToolStripMenuItem.Click
        frm_String.MdiParent = Me
        Me.Show()
        frm_String.Show()
    End Sub
End Class
